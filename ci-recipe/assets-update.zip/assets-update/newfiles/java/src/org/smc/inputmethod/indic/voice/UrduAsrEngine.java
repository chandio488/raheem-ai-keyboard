/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Nullable;

/**
 * Offline Urdu dictation engine (RAHEEM AI ULTRA update, design section 2.2).
 *
 * <p>RAM rule for the 3 GB target phone: the recognizer is created ONLY when a
 * dictation session starts and is released the moment decoding finishes or the
 * panel closes — it is never loaded at IME start and never kept resident.
 * Capture is 16 kHz mono PCM16 into a fixed in-memory buffer capped at
 * {@link #MAX_CLIP_SECONDS} seconds (~960 KB); at the cap the clip auto-stops
 * and decodes (the Shruti sherpa-onnx pack is non-streaming: text arrives at
 * clip end). All work runs on this engine's single background thread; listener
 * callbacks are posted to the main thread.
 *
 * <p>Failure behaviour: every failure lands on {@link Listener#onError} — the
 * panel then offers the legacy Google voice route. An {@link OutOfMemoryError}
 * while loading releases everything before reporting. The keyboard must never
 * die because of voice.
 */
public final class UrduAsrEngine {
    private static final String TAG = UrduAsrEngine.class.getSimpleName();

    /**
     * Whether the sherpa-onnx native library is linked into this build.
     * TRUE in the single update: Farhan's Phase-0 gate PASSED on 2026-11-14
     * (the owner's own voice, decoded per sentence on the VM with the same
     * sherpa-onnx 2.0.1 + Shruti pack: numbers and mixed English exact), the
     * pinned official AAR is vendored by the build recipe (SHA-256 checked),
     * and {@link SherpaOnnxRecognizer} implements the bridge. While false,
     * {@link OfflineVoiceRouter} never routes the mic key here and the legacy
     * Google route is untouched.
     */
    private static final boolean NATIVE_LINKED = true;

    public static boolean isNativeLinked() {
        return NATIVE_LINKED;
    }

    public enum ErrorKind {
        /** Native library not linked in this build. */
        ENGINE_UNAVAILABLE,
        /** Recognizer creation failed (including out-of-memory). */
        LOAD_FAILED,
        /** Capture produced no samples (e.g. mic permission revoked mid-session). */
        NO_AUDIO,
        /** Decode threw or returned nothing usable. */
        DECODE_FAILED
    }

    public interface Listener {
        /** Capture has started; the user may speak. */
        void onListening();
        /** Live input level, 0..1, while capturing. */
        void onLevel(float level);
        /** Decoding has started (clip ended, recognizer running). */
        void onDecoding();
        /** Final recognised text for the clip (never empty). */
        void onResult(String text);
        void onError(ErrorKind kind);
    }

    private static final int SAMPLE_RATE = 16000;
    private static final int MAX_CLIP_SECONDS = 30;
    private static final int MAX_SAMPLES = SAMPLE_RATE * MAX_CLIP_SECONDS;

    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor(r -> {
        final Thread thread = new Thread(r, "UrduAsrEngine");
        thread.setDaemon(true);
        return thread;
    });

    @Nullable private UrduRecognizer mRecognizer;
    @Nullable private AudioRecord mAudioRecord;
    private final float[] mSamples = new float[MAX_SAMPLES];
    private int mSampleCount;
    private volatile boolean mCapturing;
    private volatile boolean mSessionActive;

    /**
     * Loads the recognizer (background) and starts capturing.
     * Exactly one of {@link Listener#onListening} / {@link Listener#onError}
     * follows; on success, capture runs until {@link #stopCaptureAndDecode()},
     * {@link #cancelCapture()} or the 30 s cap.
     */
    public void startSession(final File modelDir, final Listener listener) {
        if (mSessionActive) {
            return;
        }
        mSessionActive = true;
        mExecutor.execute(() -> {
            if (!isNativeLinked()) {
                mSessionActive = false;
                postError(listener, ErrorKind.ENGINE_UNAVAILABLE);
                return;
            }
            final UrduRecognizer recognizer = UrduRecognizers.create();
            if (recognizer == null) {
                mSessionActive = false;
                postError(listener, ErrorKind.ENGINE_UNAVAILABLE);
                return;
            }
            try {
                recognizer.load(modelDir);
            } catch (final Exception | OutOfMemoryError e) {
                Log.w(TAG, "Recognizer load failed", e);
                recognizer.release();
                mSessionActive = false;
                postError(listener, ErrorKind.LOAD_FAILED);
                return;
            }
            mRecognizer = recognizer;
            startCapture(listener);
        });
    }

    private void startCapture(final Listener listener) {
        final int minBufferBytes = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        final AudioRecord record;
        try {
            record = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBufferBytes, SAMPLE_RATE * 2 /* 1 s of PCM16 */));
        } catch (final RuntimeException e) {
            Log.w(TAG, "AudioRecord creation failed", e);
            releaseLocked();
            mSessionActive = false;
            postError(listener, ErrorKind.NO_AUDIO);
            return;
        }
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            record.release();
            releaseLocked();
            mSessionActive = false;
            postError(listener, ErrorKind.NO_AUDIO);
            return;
        }
        mAudioRecord = record;
        mSampleCount = 0;
        mCapturing = true;
        record.startRecording();
        mMainHandler.post(listener::onListening);
        final short[] chunk = new short[SAMPLE_RATE / 10]; // 100 ms chunks.
        while (mCapturing) {
            final int read = record.read(chunk, 0, chunk.length);
            if (read <= 0) {
                break;
            }
            final int room = MAX_SAMPLES - mSampleCount;
            final int copy = Math.min(read, room);
            double sumSquares = 0;
            for (int i = 0; i < copy; i++) {
                final float sample = chunk[i] / 32768f;
                mSamples[mSampleCount + i] = sample;
                sumSquares += sample * sample;
            }
            mSampleCount += copy;
            final float rms = (float) Math.sqrt(sumSquares / Math.max(1, copy));
            final float level = Math.min(1f, rms * 3f);
            mMainHandler.post(() -> listener.onLevel(level));
            if (mSampleCount >= MAX_SAMPLES) {
                // 30 s cap: the pack has no streaming segmentation, so the clip
                // ends here and decodes (panel hint tells the user to dictate
                // per sentence for long text).
                mCapturing = false;
                finishCaptureAndDecode(listener, true /* decode */);
                return;
            }
        }
    }

    /** Stops capture and decodes what was recorded. */
    public void stopCaptureAndDecode(final Listener listener) {
        if (!mSessionActive) {
            return;
        }
        mCapturing = false;
        mExecutor.execute(() -> finishCaptureAndDecode(listener, true /* decode */));
    }

    /** Stops capture without decoding and releases the recognizer. */
    public void cancelCapture() {
        mCapturing = false;
        mExecutor.execute(() -> {
            releaseLocked();
            mSessionActive = false;
        });
    }

    /** Releases capture + recognizer immediately (panel closing). Idempotent. */
    public void release() {
        mCapturing = false;
        mExecutor.execute(() -> {
            releaseLocked();
            mSessionActive = false;
        });
    }

    // Runs on the engine thread.
    private void finishCaptureAndDecode(final Listener listener, final boolean decode) {
        stopRecordLocked();
        final UrduRecognizer recognizer = mRecognizer;
        final int count = mSampleCount;
        if (!decode || recognizer == null) {
            releaseLocked();
            mSessionActive = false;
            return;
        }
        if (count == 0) {
            releaseLocked();
            mSessionActive = false;
            postError(listener, ErrorKind.NO_AUDIO);
            return;
        }
        mMainHandler.post(listener::onDecoding);
        final float[] clip = new float[count];
        System.arraycopy(mSamples, 0, clip, 0, count);
        String text = null;
        boolean failed = false;
        try {
            text = recognizer.decode(clip, SAMPLE_RATE);
        } catch (final Exception | OutOfMemoryError e) {
            Log.w(TAG, "Decode failed", e);
            failed = true;
        }
        // The RAM rule: native memory is freed as soon as decoding is over,
        // before the result reaches the UI.
        releaseLocked();
        mSessionActive = false;
        if (failed) {
            postError(listener, ErrorKind.DECODE_FAILED);
        } else if (text == null || text.trim().isEmpty()) {
            postError(listener, ErrorKind.DECODE_FAILED);
        } else {
            final String result = text.trim();
            mMainHandler.post(() -> listener.onResult(result));
        }
    }

    private void stopRecordLocked() {
        final AudioRecord record = mAudioRecord;
        mAudioRecord = null;
        if (record != null) {
            try {
                if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop();
                }
            } catch (final RuntimeException e) {
                Log.w(TAG, "AudioRecord stop failed", e);
            }
            record.release();
        }
    }

    private void releaseLocked() {
        stopRecordLocked();
        final UrduRecognizer recognizer = mRecognizer;
        mRecognizer = null;
        if (recognizer != null) {
            recognizer.release();
        }
        mSampleCount = 0;
    }

    private void postError(final Listener listener, final ErrorKind kind) {
        mMainHandler.post(() -> listener.onError(kind));
    }
}
