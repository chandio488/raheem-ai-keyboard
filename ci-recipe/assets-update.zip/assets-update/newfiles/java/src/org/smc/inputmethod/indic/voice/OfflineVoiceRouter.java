/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;

import com.android.inputmethod.compat.PreferenceManagerCompat;
import com.android.inputmethod.latin.RichInputMethodManager;

import java.util.List;
import java.util.Locale;

/**
 * Routing predicate for the mic key (RAHEEM AI ULTRA).
 *
 * <p>v1.3 hybrid routing (owner order and Farhan ruling, 2026-11-14): the
 * online voice IME (Google Voice Typing) is the first choice for Urdu —
 * when the network is up and a voice input method is enabled on the
 * device, the mic key keeps the legacy shortcut route so the user gets
 * Google-level recognition. The built-in offline Urdu dictation panel is
 * the automatic fallback, used only when ALL of these hold:
 * <ul>
 *   <li>the native recognizer is linked into this build
 *       ({@link UrduAsrEngine#isNativeLinked()}),</li>
 *   <li>the user has not turned the feature off
 *       ({@link #PREF_OFFLINE_VOICE_URDU_ENABLED}, default ON),</li>
 *   <li>the current subtype's language is Urdu (Navees, NLA or
 *       transliteration),</li>
 *   <li>the online route is unavailable right now: no active internet
 *       network, or no voice input method enabled on the device.</li>
 * </ul>
 * The user never switches engines by hand; the decision is re-made on
 * every mic tap. Any failure while probing the network or the input
 * method list resolves to the offline panel, which always works.
 */
public final class OfflineVoiceRouter {
    public static final String PREF_OFFLINE_VOICE_URDU_ENABLED = "offline_voice_urdu_enabled";

    private OfflineVoiceRouter() {
        // Utility class.
    }

    public static boolean shouldUseOfflineUrdu(final Context context) {
        if (!UrduAsrEngine.isNativeLinked()) {
            return false;
        }
        final boolean enabled = PreferenceManagerCompat.getDeviceSharedPreferences(context)
                .getBoolean(PREF_OFFLINE_VOICE_URDU_ENABLED, true /* defaultValue */);
        if (!enabled) {
            return false;
        }
        final Locale locale = RichInputMethodManager.getInstance().getCurrentSubtypeLocale();
        if (locale == null || !"ur".equals(locale.getLanguage())) {
            return false;
        }
        // Hybrid rule: online + a voice IME present -> Google route wins.
        if (isNetworkConnected(context) && hasVoiceInputMethod(context)) {
            return false;
        }
        return true;
    }

    private static boolean isNetworkConnected(final Context context) {
        try {
            final ConnectivityManager cm = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                final Network network = cm.getActiveNetwork();
                if (network == null) {
                    return false;
                }
                final NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                // Farhan condition (reply 21): a merely present network is
                // not proof the online route works — require VALIDATED
                // internet where the platform reports it (API 23+).
                return caps != null
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            }
            @SuppressWarnings("deprecation")
            final NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (final Exception e) {
            // Permission or platform failure: report "offline" so the
            // built-in panel is used instead of a dead end.
            return false;
        }
    }

    private static boolean hasVoiceInputMethod(final Context context) {
        try {
            final InputMethodManager imm = (InputMethodManager)
                    context.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return false;
            }
            final List<InputMethodInfo> list = imm.getEnabledInputMethodList();
            for (final InputMethodInfo info : list) {
                final int count = info.getSubtypeCount();
                for (int i = 0; i < count; i++) {
                    final InputMethodSubtype subtype = info.getSubtypeAt(i);
                    if (subtype != null && "voice".equals(subtype.getMode())) {
                        return true;
                    }
                }
            }
            return false;
        } catch (final Exception e) {
            return false;
        }
    }
}
