/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.phrases;

import org.json.JSONException;
import org.json.JSONObject;

import javax.annotation.Nullable;

/**
 * One quick phrase (RAHEEM AI ULTRA update, Farhan ruling 8). Modelled on
 * {@code ClipboardHistoryEntry}: immutable value object with JSON round-trip.
 * Built-in entries ship in {@code res/raw/quick_phrases.json}; user entries are
 * created in the panel / settings and are the only ones that can be deleted —
 * built-ins are hidden instead and can be restored via {@link PhraseStore#resetToDefaults()}.
 */
public final class PhraseEntry {
    public final String mId;
    public final String mText;
    public final String mCategoryId;
    public final boolean mBuiltin;
    public final boolean mFavorite;
    public final boolean mHidden;
    public final long mLastUsedMillis;

    public PhraseEntry(final String id, final String text, final String categoryId,
            final boolean builtin, final boolean favorite, final boolean hidden,
            final long lastUsedMillis) {
        mId = id;
        mText = text;
        mCategoryId = categoryId;
        mBuiltin = builtin;
        mFavorite = favorite;
        mHidden = hidden;
        mLastUsedMillis = lastUsedMillis;
    }

    public PhraseEntry withFavorite(final boolean favorite) {
        return new PhraseEntry(mId, mText, mCategoryId, mBuiltin, favorite, mHidden,
                mLastUsedMillis);
    }

    public PhraseEntry withHidden(final boolean hidden) {
        return new PhraseEntry(mId, mText, mCategoryId, mBuiltin, mFavorite, hidden,
                mLastUsedMillis);
    }

    public PhraseEntry withTextAndCategory(final String text, final String categoryId) {
        return new PhraseEntry(mId, text, categoryId, mBuiltin, mFavorite, mHidden,
                mLastUsedMillis);
    }

    public PhraseEntry withLastUsed(final long lastUsedMillis) {
        return new PhraseEntry(mId, mText, mCategoryId, mBuiltin, mFavorite, mHidden,
                lastUsedMillis);
    }

    public JSONObject toJson() throws JSONException {
        final JSONObject json = new JSONObject();
        json.put("id", mId);
        json.put("text", mText);
        json.put("category", mCategoryId);
        json.put("builtin", mBuiltin);
        json.put("favorite", mFavorite);
        json.put("hidden", mHidden);
        json.put("lastUsed", mLastUsedMillis);
        return json;
    }

    @Nullable
    public static PhraseEntry fromJson(final JSONObject json) {
        final String id = json.optString("id", null);
        final String text = json.optString("text", null);
        if (id == null || text == null) {
            return null;
        }
        return new PhraseEntry(id, text, json.optString("category", "everyday"),
                json.optBoolean("builtin"), json.optBoolean("favorite"),
                json.optBoolean("hidden"), json.optLong("lastUsed"));
    }

    /** Entry parsed from the bundled seed file (no per-user state yet). */
    @Nullable
    public static PhraseEntry fromSeedJson(final JSONObject json) {
        final String id = json.optString("id", null);
        final String text = json.optString("text", null);
        if (id == null || text == null) {
            return null;
        }
        return new PhraseEntry(id, text, json.optString("category", "everyday"),
                true /* builtin */, false /* favorite */, false /* hidden */,
                0 /* lastUsedMillis */);
    }
}
