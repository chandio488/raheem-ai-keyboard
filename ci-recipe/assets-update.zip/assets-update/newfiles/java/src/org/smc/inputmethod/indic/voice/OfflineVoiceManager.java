/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.android.inputmethod.latin.R;
import com.android.inputmethod.latin.utils.ExecutorUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

/**
 * Owns the offline Urdu voice model on disk (RAHEEM AI ULTRA update, design 2.2).
 *
 * <p>The model is NEVER bundled in the APK. On the user's explicit tap in the
 * dictation panel it downloads the pinned file set of
 * {@code udgamlabs/Shruti-ONNX} / {@code ur/sherpa-onnx} (~54 MB, Apache-2.0)
 * into app-private storage ({@code files/voice/ur-sherpa/}). Every file's
 * SHA-256 is verified against the manifest shipped in
 * {@code R.raw.voice_model_manifest}; only when ALL files verify is a
 * {@code READY} marker written — a model directory without the marker is
 * never loaded. A mismatch deletes the offending file and errors out.
 *
 * <p>All I/O runs on the keyboard background executor; callbacks are posted to
 * the main thread. Downloads are resume-by-file: a fully downloaded + verified
 * file is skipped on retry; partial transfers use a {@code .part} suffix and
 * restart that one file.
 */
public final class OfflineVoiceManager {
    private static final String TAG = OfflineVoiceManager.class.getSimpleName();

    public enum State {
        ABSENT, DOWNLOADING, VERIFYING, READY, ERROR
    }

    public interface Listener {
        void onDownloadProgress(long bytesDone, long bytesTotal);
        void onStateChanged(State state);
    }

    private static final String MODEL_DIR_NAME = "voice/ur-sherpa";
    private static final String READY_MARKER = "READY";
    private static final String PART_SUFFIX = ".part";
    private static final int BUFFER_BYTES = 64 * 1024;

    private static final class ModelFile {
        final String mName;
        final long mBytes;
        final String mSha256;

        ModelFile(final String name, final long bytes, final String sha256) {
            mName = name;
            mBytes = bytes;
            mSha256 = sha256;
        }
    }

    private static OfflineVoiceManager sInstance;

    public static synchronized OfflineVoiceManager init(final Context context) {
        if (sInstance == null) {
            sInstance = new OfflineVoiceManager(context.getApplicationContext());
        }
        return sInstance;
    }

    private final Context mContext;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private final List<ModelFile> mModelFiles = new ArrayList<>();
    private String mBaseUrl = "";
    private long mTotalBytes;
    private volatile boolean mDownloading;
    private volatile boolean mCancelRequested;
    private volatile State mTransientState;
    @Nullable private volatile String mLastError;
    @Nullable private Listener mListener;

    private OfflineVoiceManager(final Context context) {
        mContext = context;
        loadManifest();
    }

    public void setListener(@Nullable final Listener listener) {
        mListener = listener;
    }

    public File getModelDir() {
        final File dir = new File(mContext.getFilesDir(), MODEL_DIR_NAME);
        dir.mkdirs();
        return dir;
    }

    public long getTotalBytes() {
        return mTotalBytes;
    }

    /** Bytes of manifest files already fully present on disk (verified or not). */
    public long getDownloadedBytes() {
        final File dir = getModelDir();
        long total = 0;
        for (final ModelFile file : mModelFiles) {
            final File f = new File(dir, file.mName);
            if (f.isFile()) {
                total += Math.min(f.length(), file.mBytes);
            }
        }
        return total;
    }

    /**
     * True only when the READY marker exists (written after every file passed
     * SHA-256 verification) and every manifest file is present at full size.
     */
    public boolean isModelReady() {
        final File dir = getModelDir();
        if (!new File(dir, READY_MARKER).isFile()) {
            return false;
        }
        for (final ModelFile file : mModelFiles) {
            final File f = new File(dir, file.mName);
            if (!f.isFile() || f.length() != file.mBytes) {
                return false;
            }
        }
        return true;
    }

    public State getState() {
        if (mDownloading) {
            return mTransientState == State.VERIFYING ? State.VERIFYING : State.DOWNLOADING;
        }
        if (isModelReady()) {
            return State.READY;
        }
        if (mTransientState == State.ERROR) {
            return State.ERROR;
        }
        return State.ABSENT;
    }

    @Nullable
    public String getLastError() {
        return mLastError;
    }

    public void startDownload() {
        if (mDownloading) {
            return;
        }
        if (mModelFiles.isEmpty() || mBaseUrl.isEmpty()) {
            mLastError = "voice_model_manifest.json missing or empty";
            mTransientState = State.ERROR;
            notifyStateChanged();
            return;
        }
        mDownloading = true;
        mCancelRequested = false;
        mLastError = null;
        mTransientState = State.DOWNLOADING;
        notifyStateChanged();
        ExecutorUtils.getBackgroundExecutor(ExecutorUtils.KEYBOARD)
                .execute(this::downloadAllFiles);
    }

    public void cancelDownload() {
        mCancelRequested = true;
    }

    /** Deletes the model and its marker; the next panel open returns to ABSENT. */
    public void deleteModel() {
        if (mDownloading) {
            mCancelRequested = true;
        }
        ExecutorUtils.getBackgroundExecutor(ExecutorUtils.KEYBOARD).execute(() -> {
            final File dir = getModelDir();
            final File[] files = dir.listFiles();
            if (files != null) {
                for (final File f : files) {
                    f.delete();
                }
            }
            mTransientState = null;
            mLastError = null;
            notifyStateChanged();
        });
    }

    private void downloadAllFiles() {
        final File dir = getModelDir();
        try {
            long doneBytes = getDownloadedBytes();
            notifyProgress(doneBytes);
            for (final ModelFile file : mModelFiles) {
                if (mCancelRequested) {
                    finishDownload(false /* success */, null /* error */);
                    return;
                }
                final File target = new File(dir, file.mName);
                if (target.isFile() && target.length() == file.mBytes
                        && file.mSha256.equals(sha256Hex(target))) {
                    continue; // Already downloaded and verified in an earlier run.
                }
                downloadOneFile(file, target);
                doneBytes += file.mBytes;
                notifyProgress(Math.min(doneBytes, mTotalBytes));
            }
            mTransientState = State.VERIFYING;
            notifyStateChanged();
            // Final gate: EVERY file must verify before the marker is written.
            for (final ModelFile file : mModelFiles) {
                final File target = new File(dir, file.mName);
                if (!target.isFile() || target.length() != file.mBytes
                        || !file.mSha256.equals(sha256Hex(target))) {
                    target.delete();
                    finishDownload(false /* success */,
                            "SHA-256 mismatch: " + file.mName);
                    return;
                }
            }
            writeReadyMarker(dir);
            finishDownload(true /* success */, null /* error */);
        } catch (final IOException | NoSuchAlgorithmException e) {
            Log.w(TAG, "Model download failed", e);
            finishDownload(false /* success */, e.getMessage());
        }
    }

    private void downloadOneFile(final ModelFile file, final File target)
            throws IOException {
        final File part = new File(target.getParentFile(), file.mName + PART_SUFFIX);
        final URL url = new URL(mBaseUrl + file.mName);
        final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(60_000);
        connection.setInstanceFollowRedirects(true);
        try {
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException("HTTP " + connection.getResponseCode()
                        + " for " + file.mName);
            }
            try (InputStream in = connection.getInputStream();
                    FileOutputStream out = new FileOutputStream(part)) {
                final byte[] buffer = new byte[BUFFER_BYTES];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    if (mCancelRequested) {
                        return; // The .part file stays; resume-by-file restarts it.
                    }
                    out.write(buffer, 0, read);
                }
            }
        } finally {
            connection.disconnect();
        }
        if (mCancelRequested) {
            return;
        }
        if (part.length() != file.mBytes) {
            part.delete();
            throw new IOException("Size mismatch for " + file.mName
                    + ": got " + part.length() + ", expected " + file.mBytes);
        }
        if (!part.renameTo(target)) {
            throw new IOException("Could not move " + file.mName + " into place");
        }
    }

    private void writeReadyMarker(final File dir) throws IOException {
        final File marker = new File(dir, READY_MARKER);
        try (FileOutputStream out = new FileOutputStream(marker)) {
            out.write("shruti-ur sherpa-onnx verified\n".getBytes(StandardCharsets.UTF_8));
        }
    }

    private void finishDownload(final boolean success, @Nullable final String error) {
        mDownloading = false;
        if (success) {
            mTransientState = State.READY;
            mLastError = null;
        } else if (mCancelRequested) {
            mTransientState = null; // Back to ABSENT (partial files kept for resume).
            mLastError = null;
        } else {
            mTransientState = State.ERROR;
            mLastError = error;
        }
        notifyStateChanged();
    }

    private void notifyProgress(final long doneBytes) {
        final Listener listener = mListener;
        if (listener != null) {
            mMainHandler.post(() -> listener.onDownloadProgress(doneBytes, mTotalBytes));
        }
    }

    private void notifyStateChanged() {
        final Listener listener = mListener;
        if (listener != null) {
            final State state = getState();
            mMainHandler.post(() -> listener.onStateChanged(state));
        }
    }

    private void loadManifest() {
        try (InputStream in = mContext.getResources().openRawResource(
                R.raw.voice_model_manifest)) {
            final byte[] bytes = new byte[in.available()];
            int offset = 0;
            while (offset < bytes.length) {
                final int read = in.read(bytes, offset, bytes.length - offset);
                if (read < 0) {
                    break;
                }
                offset += read;
            }
            final JSONObject manifest =
                    new JSONObject(new String(bytes, 0, offset, StandardCharsets.UTF_8));
            mBaseUrl = manifest.optString("baseUrl", "");
            mTotalBytes = manifest.optLong("totalBytes", 0);
            final JSONArray files = manifest.getJSONArray("files");
            long sum = 0;
            for (int i = 0; i < files.length(); i++) {
                final JSONObject entry = files.getJSONObject(i);
                final ModelFile file = new ModelFile(entry.getString("name"),
                        entry.getLong("bytes"), entry.getString("sha256"));
                mModelFiles.add(file);
                sum += file.mBytes;
            }
            if (mTotalBytes <= 0) {
                mTotalBytes = sum;
            }
        } catch (final IOException | JSONException e) {
            Log.w(TAG, "Could not load voice model manifest", e);
            mModelFiles.clear();
            mBaseUrl = "";
            mTotalBytes = 0;
        }
    }

    private static String sha256Hex(final File file)
            throws IOException, NoSuchAlgorithmException {
        final MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            final byte[] buffer = new byte[BUFFER_BYTES];
            int read;
            while ((read = in.read(buffer)) != -1) {
                digest.update(buffer, 0, read);
            }
        }
        final StringBuilder sb = new StringBuilder(64);
        for (final byte b : digest.digest()) {
            sb.append(String.format("%02x", b & 0xFF));
        }
        return sb.toString();
    }
}
