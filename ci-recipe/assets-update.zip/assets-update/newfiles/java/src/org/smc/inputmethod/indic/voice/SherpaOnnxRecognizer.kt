/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineMoonshineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import java.io.File

/**
 * sherpa-onnx backed [UrduRecognizer] for the Shruti Urdu Moonshine pack
 * (RAHEEM AI ULTRA single update — voice linked after the owner's real-voice
 * Phase-0 test PASSED on 2026-11-14).
 *
 * The library is the pinned official release AAR
 * `sherpa-onnx-2.0.1.aar` (SHA-256 verified by the build recipe), the same
 * sherpa-onnx version (2.0.1) whose Python decoder recognised the owner's
 * own voice in the Phase-0 test. The model files live in the app-private
 * directory managed by [OfflineVoiceManager] (downloaded on first use and
 * SHA-256 verified there — never bundled in the APK):
 * preprocess.onnx, encode.onnx, uncached_decode.onnx, cached_decode.onnx,
 * tokens.txt.
 *
 * Segmentation rule (Farhan, reply 11): decoding is per utterance — the
 * engine captures at most 30 s and this bridge decodes exactly that one
 * clip. Whole-file one-shot decoding is what made the model loop on the
 * owner's 114.8 s test file, so it never happens here. Repetition guard:
 * decoded text is shown in the dictation panel's RESULT preview before
 * anything is inserted, so a degenerate repeat is visible to the user and
 * is never silently deleted or silently committed.
 */
class SherpaOnnxRecognizer : UrduRecognizer {

    private var recognizer: OfflineRecognizer? = null

    override fun load(modelDir: File) {
        val moonshine = OfflineMoonshineModelConfig(
            preprocessor = File(modelDir, "preprocess.onnx").absolutePath,
            encoder = File(modelDir, "encode.onnx").absolutePath,
            uncachedDecoder = File(modelDir, "uncached_decode.onnx").absolutePath,
            cachedDecoder = File(modelDir, "cached_decode.onnx").absolutePath,
        )
        val modelConfig = OfflineModelConfig(
            moonshine = moonshine,
            tokens = File(modelDir, "tokens.txt").absolutePath,
            numThreads = 2,
            modelType = "moonshine",
        )
        val config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = modelConfig,
            decodingMethod = "greedy_search",
        )
        // AssetManager is null: the model is loaded from plain files in
        // app-private storage, not from APK assets.
        recognizer = OfflineRecognizer(null, config)
    }

    override fun decode(samples: FloatArray, sampleRate: Int): String {
        val rec = recognizer
            ?: throw IllegalStateException("recognizer not loaded")
        val stream = rec.createStream()
        try {
            stream.acceptWaveform(samples, sampleRate)
            rec.decode(stream)
            return rec.getResult(stream).text
        } finally {
            stream.release()
        }
    }

    override fun release() {
        recognizer?.release()
        recognizer = null
    }
}
