/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import java.io.File;

/**
 * The native-recognizer seam for offline Urdu dictation.
 *
 * <p>STATUS (single update, voice linked 2026-11-14): the pinned official
 * sherpa-onnx 2.0.1 Android AAR is vendored into {@code java/libs/} by the
 * build recipe (SHA-256 verified) and the flatDir dependency in
 * {@code build.gradle} is enabled; Farhan's Phase-0 gate PASSED with the
 * owner's own voice (per-sentence decode, 2026-11-14). The bridge is
 * {@link SherpaOnnxRecognizer} (Kotlin, same package). Decoding is per
 * utterance (the engine caps a clip at 30 s) — never one-shot whole-file,
 * which is what made the model loop on long recordings.
 *
 * <p>Reference wiring for the sherpa-onnx Moonshine pack in this repo
 * ({@code ur/sherpa-onnx/} files: preprocess.onnx, encode.onnx,
 * uncached_decode.onnx, cached_decode.onnx, tokens.txt), from the official
 * sherpa-onnx Android API ({@code com.k2fsa.sherpa.onnx}):
 * <pre>
 *   val modelConfig = OfflineModelConfig(
 *       moonshine = OfflineMoonshineModelConfig(
 *           preprocessor    = File(dir, "preprocess.onnx").path,
 *           encoder         = File(dir, "encode.onnx").path,
 *           uncachedDecoder = File(dir, "uncached_decode.onnx").path,
 *           cachedDecoder   = File(dir, "cached_decode.onnx").path),
 *       tokens = File(dir, "tokens.txt").path,
 *       numThreads = 2, debug = false, modelType = "moonshine")
 *   val config = OfflineRecognizerConfig(
 *       featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
 *       modelConfig = modelConfig, decodingMethod = "greedy_search")
 *   val recognizer = OfflineRecognizer(config = config)
 *   val stream = recognizer.createStream()
 *   stream.acceptWaveform(samples, sampleRate = 16000)
 *   recognizer.decode(stream)
 *   val text = recognizer.getResult(stream).text
 *   stream.release(); recognizer.release()
 * </pre>
 * The API is Kotlin-first: from Java, the data-class constructors take every
 * parameter (no defaults), so the bridge is best implemented as a small Kotlin
 * class or via the library's builder-style helpers of the vendored version —
 * confirm against the vendored AAR's actual API surface when linking. The
 * model is Urdu-only: no language auto-detect (force this pack).
 */
interface UrduRecognizer {
    /** Loads the model from {@code modelDir}. Called on a background thread. */
    void load(File modelDir) throws Exception;

    /** Decodes one captured clip (16 kHz mono float samples in [-1, 1]). */
    String decode(float[] samples, int sampleRate) throws Exception;

    /** Frees all native memory. Safe to call more than once. */
    void release();
}

final class UrduRecognizers {
    private UrduRecognizers() {
        // Utility class.
    }

    /**
     * Creates the sherpa-onnx backed recognizer, or null when the native
     * library is not linked into this build.
     */
    static UrduRecognizer create() {
        if (!UrduAsrEngine.isNativeLinked()) {
            return null;
        }
        return new SherpaOnnxRecognizer();
    }
}
