/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.settings

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText

import androidx.preference.Preference
import androidx.preference.PreferenceCategory

import com.android.inputmethod.latin.R

import org.smc.inputmethod.indic.phrases.PhraseStore

/**
 * Quick Phrases settings (RAHEEM AI ULTRA update): lists every phrase including
 * hidden built-ins, and offers add / edit / hide-or-delete / restore-defaults.
 * The static screen comes from prefs_screen_phrases.xml; the phrase rows are
 * built here from [PhraseStore], the same store the keyboard panel uses.
 */
class PhrasesSettingsFragment : SubScreenFragment() {

    private lateinit var store: PhraseStore

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        super.onCreatePreferences(savedInstanceState, rootKey)
        addPreferencesFromResource(R.xml.prefs_screen_phrases)
        store = PhraseStore.init(requireContext())
        findPreference<Preference>("phrases_add")?.setOnPreferenceClickListener {
            showEditor(null)
            true
        }
        findPreference<Preference>("phrases_reset")?.setOnPreferenceClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(R.string.phrases_reset_title)
                .setMessage(R.string.phrases_reset_confirm)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.phrases_reset_title) { _, _ ->
                    store.resetToDefaults()
                    rebuildList()
                }
                .show()
            true
        }
        rebuildList()
    }

    override fun onResume() {
        super.onResume()
        if (::store.isInitialized) {
            rebuildList()
        }
    }

    private fun rebuildList() {
        val category = findPreference<PreferenceCategory>("phrases_all") ?: return
        category.removeAll()
        for (entry in store.getAllPhrases()) {
            val pref = Preference(requireContext())
            pref.title = entry.mText
            val categoryLabel = store.categoryForId(entry.mCategoryId)?.mLabel ?: entry.mCategoryId
            pref.summary = if (entry.mHidden) {
                categoryLabel + " — " + getString(R.string.phrases_hidden)
            } else {
                categoryLabel
            }
            pref.isPersistent = false
            pref.setOnPreferenceClickListener {
                showEditor(entry.mId)
                true
            }
            category.addPreference(pref)
        }
    }

    /** Add dialog when [entryId] is null; edit dialog for the stored entry otherwise. */
    private fun showEditor(entryId: String?) {
        val entry = entryId?.let { id -> store.getAllPhrases().firstOrNull { it.mId == id } }
        val editText = EditText(requireContext())
        editText.setSingleLine(false)
        editText.maxLines = 3
        if (entry != null) {
            editText.setText(entry.mText)
            editText.setSelection(entry.mText.length)
        }
        val builder = AlertDialog.Builder(requireContext())
            .setTitle(if (entry == null) R.string.phrases_add_title else R.string.phrases_edit)
            .setView(editText)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.phrases_save) { _, _ ->
                val text = editText.text.toString().trim()
                if (text.isNotEmpty()) {
                    when {
                        entry == null -> store.add(text, "everyday")
                        entry.mBuiltin -> {
                            // Editing a built-in saves a user copy and hides the original.
                            store.add(text, entry.mCategoryId)
                            store.setHidden(entry.mId, true)
                        }
                        else -> store.update(entry.mId, text, entry.mCategoryId)
                    }
                    rebuildList()
                }
            }
        if (entry != null) {
            if (entry.mBuiltin) {
                builder.setNeutralButton(
                    if (entry.mHidden) R.string.phrases_unhide else R.string.phrases_hide
                ) { _, _ ->
                    store.setHidden(entry.mId, !entry.mHidden)
                    rebuildList()
                }
            } else {
                builder.setNeutralButton(R.string.phrases_delete) { _, _ ->
                    store.delete(entry.mId)
                    rebuildList()
                }
            }
        }
        builder.show()
    }
}
