/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.phrases;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.util.Log;

import com.android.inputmethod.compat.PreferenceManagerCompat;
import com.android.inputmethod.latin.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.Nullable;

/**
 * Store for the Quick Islamic Phrases panel (RAHEEM AI ULTRA update, Farhan ruling 8).
 *
 * <p>Persistence follows the clipboard store's pattern (singleton, lazy load, listener):
 * the whole phrase book is one JSON object in device-protected SharedPreferences under
 * {@link #PREF_KEY}. On first run it is seeded from {@code R.raw.quick_phrases}; after
 * that everything is local — no network, no API. Categories are fixed (they ship with
 * the seed); phrases carry per-user state (favorite / hidden / lastUsed).
 */
public final class PhraseStore {
    private static final String TAG = PhraseStore.class.getSimpleName();

    /** Device-protected prefs key holding the whole phrase book as one JSON object. */
    public static final String PREF_KEY = "quick_phrases_v1";

    /** Pseudo-category ids used by the panel's chip row (never stored on entries). */
    public static final String CHIP_FAVORITES = "@favorites";
    public static final String CHIP_RECENTS = "@recents";

    private static final int MAX_RECENTS = 10;

    public interface OnPhrasesChangedListener {
        void onPhrasesChanged();
    }

    /** A phrase category: stable id + display label (Urdu). */
    public static final class Category {
        public final String mId;
        public final String mLabel;

        public Category(final String id, final String label) {
            mId = id;
            mLabel = label;
        }
    }

    private static PhraseStore sInstance;

    public static synchronized PhraseStore init(final Context context) {
        if (sInstance == null) {
            sInstance = new PhraseStore(context.getApplicationContext());
        }
        return sInstance;
    }

    private final Context mContext;
    private final ArrayList<Category> mCategories = new ArrayList<>();
    private final ArrayList<PhraseEntry> mEntries = new ArrayList<>();
    private boolean mLoaded;
    @Nullable private OnPhrasesChangedListener mOnPhrasesChangedListener;

    private PhraseStore(final Context context) {
        mContext = context;
    }

    public void setOnPhrasesChangedListener(@Nullable final OnPhrasesChangedListener listener) {
        mOnPhrasesChangedListener = listener;
    }

    public List<Category> getCategories() {
        synchronized (mEntries) {
            loadLocked();
            return new ArrayList<>(mCategories);
        }
    }

    /** All phrases the panel may show (hidden ones excluded), in stored order. */
    public List<PhraseEntry> getVisiblePhrases() {
        synchronized (mEntries) {
            loadLocked();
            final ArrayList<PhraseEntry> visible = new ArrayList<>();
            for (final PhraseEntry entry : mEntries) {
                if (!entry.mHidden) {
                    visible.add(entry);
                }
            }
            return visible;
        }
    }

    /** Everything, including hidden built-ins — for the settings screen. */
    public List<PhraseEntry> getAllPhrases() {
        synchronized (mEntries) {
            loadLocked();
            return new ArrayList<>(mEntries);
        }
    }

    public List<PhraseEntry> getByCategory(final String categoryId) {
        final ArrayList<PhraseEntry> result = new ArrayList<>();
        for (final PhraseEntry entry : getVisiblePhrases()) {
            if (entry.mCategoryId.equals(categoryId)) {
                result.add(entry);
            }
        }
        return result;
    }

    public List<PhraseEntry> getFavorites() {
        final ArrayList<PhraseEntry> result = new ArrayList<>();
        for (final PhraseEntry entry : getVisiblePhrases()) {
            if (entry.mFavorite) {
                result.add(entry);
            }
        }
        return result;
    }

    /** Recently used phrases, most recent first, capped at {@link #MAX_RECENTS}. */
    public List<PhraseEntry> getRecents() {
        final ArrayList<PhraseEntry> result = new ArrayList<>();
        for (final PhraseEntry entry : getVisiblePhrases()) {
            if (entry.mLastUsedMillis > 0) {
                result.add(entry);
            }
        }
        Collections.sort(result,
                (a, b) -> Long.compare(b.mLastUsedMillis, a.mLastUsedMillis));
        if (result.size() > MAX_RECENTS) {
            return new ArrayList<>(result.subList(0, MAX_RECENTS));
        }
        return result;
    }

    @Nullable
    public Category categoryForId(final String categoryId) {
        synchronized (mEntries) {
            loadLocked();
            for (final Category category : mCategories) {
                if (category.mId.equals(categoryId)) {
                    return category;
                }
            }
            return null;
        }
    }

    /** Adds a user phrase; returns the created entry. */
    @Nullable
    public PhraseEntry add(final String text, final String categoryId) {
        final String trimmed = text == null ? "" : text.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        final PhraseEntry entry = new PhraseEntry("u" + System.currentTimeMillis(), trimmed,
                categoryId, false /* builtin */, false /* favorite */, false /* hidden */,
                0 /* lastUsedMillis */);
        synchronized (mEntries) {
            loadLocked();
            mEntries.add(entry);
        }
        onMutated();
        return entry;
    }

    public void update(final String id, final String text, final String categoryId) {
        final String trimmed = text == null ? "" : text.trim();
        if (trimmed.isEmpty()) {
            return;
        }
        synchronized (mEntries) {
            loadLocked();
            final int index = indexOfLocked(id);
            if (index >= 0) {
                mEntries.set(index, mEntries.get(index).withTextAndCategory(trimmed, categoryId));
            }
        }
        onMutated();
    }

    public void setHidden(final String id, final boolean hidden) {
        synchronized (mEntries) {
            loadLocked();
            final int index = indexOfLocked(id);
            if (index >= 0) {
                mEntries.set(index, mEntries.get(index).withHidden(hidden));
            }
        }
        onMutated();
    }

    /** User phrases are deleted outright; built-ins are hidden (restorable), never deleted. */
    public void delete(final String id) {
        synchronized (mEntries) {
            loadLocked();
            final int index = indexOfLocked(id);
            if (index < 0) {
                return;
            }
            final PhraseEntry entry = mEntries.get(index);
            if (entry.mBuiltin) {
                mEntries.set(index, entry.withHidden(true));
            } else {
                mEntries.remove(index);
            }
        }
        onMutated();
    }

    public void toggleFavorite(final String id) {
        synchronized (mEntries) {
            loadLocked();
            final int index = indexOfLocked(id);
            if (index >= 0) {
                final PhraseEntry entry = mEntries.get(index);
                mEntries.set(index, entry.withFavorite(!entry.mFavorite));
            }
        }
        onMutated();
    }

    public void recordUse(final String id) {
        synchronized (mEntries) {
            loadLocked();
            final int index = indexOfLocked(id);
            if (index >= 0) {
                mEntries.set(index,
                        mEntries.get(index).withLastUsed(System.currentTimeMillis()));
            }
        }
        onMutated();
    }

    /** Drops all user state and re-seeds from the bundled defaults. */
    public void resetToDefaults() {
        synchronized (mEntries) {
            mCategories.clear();
            mEntries.clear();
            seedLocked();
        }
        onMutated();
    }

    private int indexOfLocked(final String id) {
        for (int i = 0; i < mEntries.size(); i++) {
            if (mEntries.get(i).mId.equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private void onMutated() {
        persistLocked();
        final OnPhrasesChangedListener listener = mOnPhrasesChangedListener;
        if (listener != null) {
            listener.onPhrasesChanged();
        }
    }

    private void loadLocked() {
        if (mLoaded) {
            return;
        }
        mLoaded = true;
        final SharedPreferences prefs =
                PreferenceManagerCompat.getDeviceSharedPreferences(mContext);
        final String stored = prefs.getString(PREF_KEY, null);
        if (stored != null) {
            try {
                parseBookLocked(new JSONObject(stored));
                return;
            } catch (final JSONException e) {
                Log.w(TAG, "Could not parse stored phrases; re-seeding", e);
                mCategories.clear();
                mEntries.clear();
            }
        }
        seedLocked();
        persistLocked();
    }

    private void parseBookLocked(final JSONObject book) throws JSONException {
        final JSONArray categories = book.getJSONArray("categories");
        for (int i = 0; i < categories.length(); i++) {
            final JSONObject category = categories.getJSONObject(i);
            mCategories.add(new Category(category.getString("id"),
                    category.getString("label")));
        }
        final JSONArray phrases = book.getJSONArray("phrases");
        for (int i = 0; i < phrases.length(); i++) {
            final PhraseEntry entry = PhraseEntry.fromJson(phrases.getJSONObject(i));
            if (entry != null) {
                mEntries.add(entry);
            }
        }
    }

    private void seedLocked() {
        final JSONObject seed = readSeedJson();
        if (seed == null) {
            return;
        }
        try {
            final JSONArray categories = seed.getJSONArray("categories");
            for (int i = 0; i < categories.length(); i++) {
                final JSONObject category = categories.getJSONObject(i);
                mCategories.add(new Category(category.getString("id"),
                        category.getString("label")));
            }
            final JSONArray phrases = seed.getJSONArray("phrases");
            for (int i = 0; i < phrases.length(); i++) {
                final PhraseEntry entry =
                        PhraseEntry.fromSeedJson(phrases.getJSONObject(i));
                if (entry != null) {
                    mEntries.add(entry);
                }
            }
        } catch (final JSONException e) {
            Log.w(TAG, "Could not parse bundled quick_phrases.json", e);
        }
    }

    @Nullable
    private JSONObject readSeedJson() {
        final Resources res = mContext.getResources();
        try (InputStream in = res.openRawResource(R.raw.quick_phrases);
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(in, StandardCharsets.UTF_8))) {
            final StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return new JSONObject(sb.toString());
        } catch (final IOException | JSONException e) {
            Log.w(TAG, "Could not read bundled quick_phrases.json", e);
            return null;
        }
    }

    private void persistLocked() {
        final JSONObject book = new JSONObject();
        try {
            final JSONArray categories = new JSONArray();
            for (final Category category : mCategories) {
                categories.put(new JSONObject()
                        .put("id", category.mId)
                        .put("label", category.mLabel));
            }
            book.put("categories", categories);
            final JSONArray phrases = new JSONArray();
            synchronized (mEntries) {
                for (final PhraseEntry entry : mEntries) {
                    phrases.put(entry.toJson());
                }
            }
            book.put("phrases", phrases);
        } catch (final JSONException e) {
            Log.w(TAG, "Could not serialize phrases", e);
            return;
        }
        PreferenceManagerCompat.getDeviceSharedPreferences(mContext).edit()
                .putString(PREF_KEY, book.toString()).apply();
    }
}
