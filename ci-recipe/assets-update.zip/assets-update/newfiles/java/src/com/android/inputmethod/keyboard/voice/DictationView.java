/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.inputmethod.keyboard.voice;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.inputmethod.keyboard.clipboard.ClipboardHistoryView;
import com.android.inputmethod.latin.R;
import com.android.inputmethod.latin.utils.ResourceUtils;

import org.smc.inputmethod.indic.voice.NameCorrector;
import org.smc.inputmethod.indic.voice.OfflineVoiceManager;
import org.smc.inputmethod.indic.voice.UrduAsrEngine;

/**
 * Offline Urdu dictation panel (RAHEEM AI ULTRA update, design section 2.2).
 *
 * <p>Opened by LatinIME (not by KeyboardState — the mic key has no key code of
 * its own) when the Urdu offline route applies. State machine:
 * NO_MODEL (download offer) → DOWNLOADING (per-file progress, cancel) →
 * LISTENING (level meter, stop/cancel) → PROCESSING (cancel discards the
 * incoming result) → auto-commit. DIRECT VOICE TYPING (v1.2, owner order
 * 2026-11-14, Farhan reply 16): when the model is ready, opening the panel
 * starts listening immediately, and the recognised text (after the Name
 * Correction Layer) is committed straight into the host editor through the
 * same listener path the v1.1 Insert button used — there is no mandatory
 * preview or copy step. The RESULT state survives only as a fallback for
 * when no listener is attached. A «use Google voice» escape is always
 * visible when not listening.
 *
 * <p>The engine lifecycle follows the RAM rule: it exists only inside a
 * session and {@link #stopDictation()} always releases it.
 */
public final class DictationView extends LinearLayout implements View.OnClickListener,
        UrduAsrEngine.Listener, OfflineVoiceManager.Listener {

    public interface OnDictationListener {
        /**
         * Commit {@code text} into the host editor. Returns false when the
         * commit was refused because the session's original editor is gone
         * (the text was held instead of landing in a wrong field).
         */
        boolean onInsertText(String text);
        /** Undo the last voice insert — verified safe by the listener. */
        void onUndoVoiceInsert();
        /** Leave the panel and use the legacy shortcut (Google) voice IME. */
        void onUseGoogleVoice();
        /** Back key: leave the panel without inserting anything. */
        void onDictationClosed();
    }

    private enum PanelState {
        NO_MODEL, DOWNLOADING, READY, LISTENING, PROCESSING, RESULT, ERROR, DONE
    }

    private OfflineVoiceManager mVoiceManager;
    private final UrduAsrEngine mEngine = new UrduAsrEngine();
    private OnDictationListener mListener;
    private PanelState mState = PanelState.NO_MODEL;
    private String mResultText;
    // Name Correction Layer (Farhan reply 12): the raw ASR text is kept
    // untouched here; the preview shows the corrected text plus a note
    // naming every change, and only the user's insert tap commits it.
    private String mRawResultText;
    private String mCorrectionNote;
    // Direct Voice Typing (v1.2, Farhan reply 17): session generation ids.
    // Cancelling marks the CURRENT session id; a result that arrives later
    // for a marked session is discarded, never committed.
    private int mSessionSeq;
    private int mCancelledSeq;
    // True when the RESULT preview holds a result whose original editor
    // vanished mid-decode — its status line explains instead of the title.
    private boolean mResultFieldChanged;
    private static final long DONE_TIMEOUT_MS = 4000;
    private final Handler mDoneTimeoutHandler = new Handler(Looper.getMainLooper());
    private final Runnable mDoneTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (mState == PanelState.DONE && mListener != null) {
                mListener.onDictationClosed();
            }
        }
    };
    private int mTotalHeight;
    private int mNavigationBarInset;
    private int mContentBasePaddingBottom;

    private View mContent;
    private TextView mStatusText;
    private TextView mResultView;
    private ProgressBar mProgressBar;
    private ProgressBar mLevelBar;
    private ImageButton mMicButton;
    private TextView mPrimaryButton;
    private TextView mSecondaryButton;

    public DictationView(final Context context, final AttributeSet attrs) {
        this(context, attrs, R.attr.emojiPalettesViewStyle);
    }

    public DictationView(final Context context, final AttributeSet attrs, final int defStyle) {
        super(context, attrs, defStyle);
        mVoiceManager = OfflineVoiceManager.init(context);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        final Resources res = getContext().getResources();
        final int width = ResourceUtils.getKeyboardContentWidth(getContext())
                + getPaddingLeft() + getPaddingRight();
        final int height = (mTotalHeight > 0
                ? mTotalHeight
                : ResourceUtils.getDefaultKeyboardHeight(res)
                        + res.getDimensionPixelSize(R.dimen.config_suggestions_strip_height)
                        + mNavigationBarInset)
                + getPaddingTop() + getPaddingBottom();
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
    }

    /** Total height to occupy — the main keyboard frame's height including the suggestion bar. */
    public void setTotalHeight(final int height) {
        if (height > 0 && height != mTotalHeight) {
            mTotalHeight = height;
            requestLayout();
        }
    }

    public void setNavigationBarInset(final int inset) {
        if (inset == mNavigationBarInset) {
            return;
        }
        mNavigationBarInset = inset;
        mContent.setPadding(mContent.getPaddingLeft(), mContent.getPaddingTop(),
                mContent.getPaddingRight(), mContentBasePaddingBottom + inset);
        requestLayout();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        final int gutter = ResourceUtils.getKeyboardGutterWidth(getContext());
        setPadding(gutter, getPaddingTop(), gutter, getPaddingBottom());
        final ImageButton backKey = findViewById(R.id.dictation_back_key);
        backKey.setOnClickListener(v -> {
            if (mListener != null) {
                mListener.onDictationClosed();
            }
        });
        mContent = findViewById(R.id.dictation_content);
        mContentBasePaddingBottom = mContent.getPaddingBottom();
        mStatusText = findViewById(R.id.dictation_status);
        mResultView = findViewById(R.id.dictation_result);
        mProgressBar = findViewById(R.id.dictation_progress);
        mLevelBar = findViewById(R.id.dictation_level);
        mMicButton = findViewById(R.id.dictation_mic_button);
        mMicButton.setOnClickListener(this);
        mMicButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 36));
        mPrimaryButton = findViewById(R.id.dictation_primary_button);
        mPrimaryButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 18));
        mPrimaryButton.setOnClickListener(this);
        mSecondaryButton = findViewById(R.id.dictation_secondary_button);
        mSecondaryButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 18));
        mSecondaryButton.setOnClickListener(this);
    }

    public void setOnDictationListener(final OnDictationListener listener) {
        mListener = listener;
    }

    public void startDictation() {
        mVoiceManager.setListener(this);
        if (mState == PanelState.LISTENING || mState == PanelState.PROCESSING) {
            // A session is already running (its panel was hidden by a frame
            // switch): re-show its live state, never restart the engine.
            setState(mState);
            return;
        }
        if (mVoiceManager.getState() == OfflineVoiceManager.State.DOWNLOADING
                || mVoiceManager.getState() == OfflineVoiceManager.State.VERIFYING) {
            setState(PanelState.DOWNLOADING);
            onDownloadProgress(mVoiceManager.getDownloadedBytes(),
                    mVoiceManager.getTotalBytes());
        } else if (mVoiceManager.isModelReady()) {
            setState(PanelState.READY);
            // Direct Voice Typing (v1.2): one tap on the keyboard mic key is
            // the whole gesture — listening starts as soon as the panel
            // opens, exactly like the Google panel the owner compared with.
            startListening();
        } else {
            setState(PanelState.NO_MODEL);
        }
    }

    private void startListening() {
        mSessionSeq++;
        mCancelledSeq = 0;
        mResultFieldChanged = false;
        mEngine.startSession(mVoiceManager.getModelDir(), this);
    }

    /** True while a recording or decode is in flight — frame switches must not kill it. */
    public boolean isSessionActive() {
        return mState == PanelState.LISTENING || mState == PanelState.PROCESSING;
    }

    public void stopDictation() {
        mDoneTimeoutHandler.removeCallbacks(mDoneTimeoutRunnable);
        mEngine.release();
        mVoiceManager.setListener(null);
    }

    // ---- Panel state rendering -------------------------------------------------

    private void setState(final PanelState state) {
        mState = state;
        if (state != PanelState.DONE) {
            mDoneTimeoutHandler.removeCallbacks(mDoneTimeoutRunnable);
        }
        mResultView.setVisibility(state == PanelState.RESULT || state == PanelState.DONE
                ? VISIBLE : GONE);
        mProgressBar.setVisibility(state == PanelState.DOWNLOADING
                || state == PanelState.PROCESSING ? VISIBLE : GONE);
        mProgressBar.setIndeterminate(state == PanelState.PROCESSING);
        mLevelBar.setVisibility(state == PanelState.LISTENING ? VISIBLE : GONE);
        mMicButton.setVisibility(state == PanelState.READY || state == PanelState.LISTENING
                || state == PanelState.PROCESSING ? VISIBLE : GONE);
        mMicButton.setEnabled(state != PanelState.PROCESSING);
        mMicButton.setImageResource(state == PanelState.LISTENING
                ? R.drawable.ic_kb_mic_off : R.drawable.ic_kb_mic);
        mPrimaryButton.setVisibility(GONE);
        mSecondaryButton.setVisibility(GONE);
        switch (state) {
            case NO_MODEL:
                mStatusText.setText(getContext().getString(R.string.dictation_download_prompt,
                        formatMegabytes(mVoiceManager.getTotalBytes())));
                showButton(mPrimaryButton, R.string.dictation_download_button);
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
            case DOWNLOADING:
                mStatusText.setText(R.string.dictation_downloading);
                showButton(mPrimaryButton, R.string.dictation_cancel);
                break;
            case READY:
                mStatusText.setText(R.string.dictation_ready_hint);
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
            case LISTENING:
                mStatusText.setText(R.string.dictation_listening);
                showButton(mPrimaryButton, R.string.dictation_stop);
                showButton(mSecondaryButton, R.string.dictation_cancel);
                break;
            case PROCESSING:
                mStatusText.setText(R.string.dictation_processing);
                showButton(mSecondaryButton, R.string.dictation_cancel);
                break;
            case RESULT:
                if (mResultFieldChanged) {
                    mStatusText.setText(R.string.dictation_field_changed);
                } else if (mCorrectionNote != null) {
                    mStatusText.setText(getContext().getString(R.string.dictation_result_title)
                            + " — " + mCorrectionNote);
                } else {
                    mStatusText.setText(R.string.dictation_result_title);
                }
                mResultView.setText(mResultText);
                showButton(mPrimaryButton, R.string.dictation_insert);
                showButton(mSecondaryButton, R.string.dictation_retry);
                break;
            case DONE:
                mStatusText.setText(R.string.dictation_inserted);
                mResultView.setText(mResultText);
                showButton(mPrimaryButton, R.string.dictation_undo);
                mDoneTimeoutHandler.postDelayed(mDoneTimeoutRunnable, DONE_TIMEOUT_MS);
                break;
            case ERROR:
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
        }
    }

    private void showButton(final TextView button, final int textRes) {
        button.setText(textRes);
        button.setVisibility(VISIBLE);
    }

    private static String formatMegabytes(final long bytes) {
        return String.format("%.0f MB", bytes / 1_000_000.0);
    }

    // ---- Clicks ------------------------------------------------------------------

    @Override
    public void onClick(final View v) {
        if (v == mMicButton) {
            if (mState == PanelState.READY) {
                startListening();
            } else if (mState == PanelState.LISTENING) {
                mEngine.stopCaptureAndDecode(this);
            }
            return;
        }
        if (v == mPrimaryButton) {
            switch (mState) {
                case NO_MODEL:
                case ERROR:
                    mVoiceManager.startDownload();
                    break;
                case DOWNLOADING:
                    mVoiceManager.cancelDownload();
                    break;
                case LISTENING:
                    mEngine.stopCaptureAndDecode(this);
                    break;
                case RESULT:
                    if (mListener != null && mResultText != null
                            && mListener.onInsertText(mResultText)) {
                        setState(PanelState.DONE);
                    }
                    break;
                case DONE:
                    if (mListener != null) {
                        mListener.onUndoVoiceInsert();
                        mListener.onDictationClosed();
                    }
                    break;
                default:
                    break;
            }
            return;
        }
        if (v == mSecondaryButton) {
            switch (mState) {
                case NO_MODEL:
                case READY:
                case ERROR:
                    if (mListener != null) {
                        mListener.onUseGoogleVoice();
                    }
                    break;
                case LISTENING:
                    mEngine.cancelCapture();
                    setState(PanelState.READY);
                    break;
                case PROCESSING:
                    // Direct Voice Typing (v1.2): decoding cannot be aborted
                    // mid-flight safely, so the tap marks this session id as
                    // cancelled; onResult drops its text when it arrives.
                    mCancelledSeq = mSessionSeq;
                    mSecondaryButton.setVisibility(GONE);
                    break;
                case RESULT:
                    setState(PanelState.READY);
                    break;
                default:
                    break;
            }
        }
    }

    // ---- UrduAsrEngine.Listener ----------------------------------------------------

    @Override
    public void onListening() {
        setState(PanelState.LISTENING);
    }

    @Override
    public void onLevel(final float level) {
        if (mState == PanelState.LISTENING) {
            mLevelBar.setProgress((int) (level * 100));
        }
    }

    @Override
    public void onDecoding() {
        setState(PanelState.PROCESSING);
    }

    @Override
    public void onResult(final String text) {
        mRawResultText = text;
        final NameCorrector.Result corrected = NameCorrector.correct(getContext(), text);
        mResultText = corrected.mText;
        mCorrectionNote = corrected.mNote;
        if (mCancelledSeq != 0 && mCancelledSeq == mSessionSeq) {
            // Cancelled while processing (Farhan reply 17): the session id
            // is marked, so even a late native result is dropped here and
            // never committed anywhere.
            mCancelledSeq = 0;
            setState(PanelState.READY);
            return;
        }
        if (mResultText == null || mResultText.trim().isEmpty()) {
            // An empty result is never auto-committed.
            setState(PanelState.ERROR);
            mStatusText.setText(R.string.dictation_no_audio);
            return;
        }
        // Direct Voice Typing (v1.2): commit straight into the host editor
        // through the exact listener path the v1.1 Insert button used.
        if (mListener != null) {
            if (mListener.onInsertText(mResultText)) {
                setState(PanelState.DONE);
            } else {
                // The original editor is gone (LatinIME verified this and
                // held the text): keep it in the preview so nothing lands
                // in a wrong field; the user may insert it explicitly.
                mResultFieldChanged = true;
                setState(PanelState.RESULT);
            }
            return;
        }
        setState(PanelState.RESULT);
    }

    @Override
    public void onError(final UrduAsrEngine.ErrorKind kind) {
        mCancelledSeq = 0;
        // setState(ERROR) leaves the status line alone, so the specific error
        // text is applied after it.
        setState(PanelState.ERROR);
        switch (kind) {
            case ENGINE_UNAVAILABLE:
                mStatusText.setText(R.string.dictation_engine_missing);
                break;
            case LOAD_FAILED:
                mStatusText.setText(R.string.dictation_load_failed);
                break;
            case NO_AUDIO:
                mStatusText.setText(R.string.dictation_no_audio);
                break;
            case DECODE_FAILED:
            default:
                mStatusText.setText(R.string.dictation_decode_failed);
                break;
        }
    }

    // ---- OfflineVoiceManager.Listener ----------------------------------------------

    @Override
    public void onDownloadProgress(final long bytesDone, final long bytesTotal) {
        if (mState == PanelState.DOWNLOADING && bytesTotal > 0) {
            mProgressBar.setIndeterminate(false);
            mProgressBar.setProgress((int) (bytesDone * 100 / bytesTotal));
        }
    }

    @Override
    public void onStateChanged(final OfflineVoiceManager.State state) {
        switch (state) {
            case DOWNLOADING:
            case VERIFYING:
                setState(PanelState.DOWNLOADING);
                break;
            case READY:
                setState(PanelState.READY);
                break;
            case ERROR:
                setState(PanelState.ERROR);
                mStatusText.setText(R.string.dictation_download_failed);
                showButton(mPrimaryButton, R.string.dictation_download_button);
                break;
            case ABSENT:
            default:
                setState(PanelState.NO_MODEL);
                break;
        }
    }
}
