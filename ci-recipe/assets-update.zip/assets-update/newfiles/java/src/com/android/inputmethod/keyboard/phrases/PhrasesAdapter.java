/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.inputmethod.keyboard.phrases;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.inputmethod.keyboard.clipboard.ClipboardHistoryView;
import com.android.inputmethod.latin.R;

import org.smc.inputmethod.indic.phrases.PhraseEntry;

import java.util.ArrayList;
import java.util.List;

/**
 * Row adapter for the phrases panel, mirroring {@code ClipboardHistoryAdapter}:
 * one tap = the phrase is committed by the panel's listener; long-press opens
 * the per-phrase menu; the star toggles favorite without committing anything.
 */
final class PhrasesAdapter extends RecyclerView.Adapter<PhrasesAdapter.ViewHolder> {

    public interface OnPhraseActionListener {
        void onPhraseClicked(PhraseEntry entry);
        void onPhraseLongClicked(PhraseEntry entry, View anchor);
        void onPhraseFavoriteToggled(PhraseEntry entry);
    }

    private final OnPhraseActionListener mListener;
    private List<PhraseEntry> mEntries = new ArrayList<>();

    PhrasesAdapter(final OnPhraseActionListener listener) {
        mListener = listener;
    }

    void setEntries(final List<PhraseEntry> entries) {
        mEntries = entries;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(
                R.layout.phrases_item, parent, false /* attachToRoot */));
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final PhraseEntry entry = mEntries.get(position);
        holder.mText.setText(entry.mText);
        // Phrase rows follow the phrase's own direction: Urdu text reads RTL even
        // when the panel chrome is LTR (design risk note (c)).
        holder.mText.setTextDirection(
                Character.getDirectionality(entry.mText.charAt(0))
                        == Character.DIRECTIONALITY_RIGHT_TO_LEFT
                        || Character.getDirectionality(entry.mText.charAt(0))
                                == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
                        ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        holder.mStar.setImageResource(entry.mFavorite
                ? R.drawable.ic_kb_star_filled : R.drawable.ic_kb_star);
        holder.mStar.setContentDescription(holder.mStar.getContext().getString(
                entry.mFavorite ? R.string.phrases_unfavorite : R.string.phrases_favorite));
        holder.itemView.setOnClickListener(v -> mListener.onPhraseClicked(entry));
        holder.itemView.setOnLongClickListener(v -> {
            mListener.onPhraseLongClicked(entry, v);
            return true;
        });
        holder.mStar.setOnClickListener(v -> mListener.onPhraseFavoriteToggled(entry));
    }

    @Override
    public int getItemCount() {
        return mEntries.size();
    }

    static final class ViewHolder extends RecyclerView.ViewHolder {
        final TextView mText;
        final ImageButton mStar;

        ViewHolder(final View itemView) {
            super(itemView);
            itemView.setBackground(
                    ClipboardHistoryView.createRoundedBackground(itemView.getContext(), 12));
            mText = itemView.findViewById(R.id.phrase_entry_text);
            mStar = itemView.findViewById(R.id.phrase_entry_star);
        }
    }
}
