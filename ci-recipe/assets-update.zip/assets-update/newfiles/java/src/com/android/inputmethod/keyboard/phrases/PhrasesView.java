/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.inputmethod.keyboard.phrases;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.inputmethod.keyboard.KeyboardActionListener;
import com.android.inputmethod.keyboard.clipboard.ClipboardHistoryView;
import com.android.inputmethod.latin.R;
import com.android.inputmethod.latin.common.Constants;
import com.android.inputmethod.latin.utils.ResourceUtils;

import org.smc.inputmethod.indic.phrases.PhraseEntry;
import org.smc.inputmethod.indic.phrases.PhraseStore;

import java.util.ArrayList;
import java.util.List;

/**
 * Quick Islamic Phrases panel (RAHEEM AI ULTRA update, Farhan ruling 8).
 *
 * <p>A structural clone of {@code ClipboardHistoryView}: header strip (back key,
 * title, add button), a category chip row (favorites / recents / the six phrase
 * categories) and a single-column list. One tap on a phrase is relayed to
 * {@link OnPhraseClickedListener} — LatinIME commits the whole text and closes
 * the panel. Long-press opens the favorite / edit / hide-or-delete menu; the
 * header's + button opens the add dialog.
 */
public final class PhrasesView extends LinearLayout implements
        View.OnClickListener, View.OnTouchListener,
        PhraseStore.OnPhrasesChangedListener,
        PhrasesAdapter.OnPhraseActionListener {

    public interface OnPhraseClickedListener {
        void onPhraseClicked(PhraseEntry entry);
    }

    private KeyboardActionListener mKeyboardActionListener =
            KeyboardActionListener.EMPTY_LISTENER;
    private OnPhraseClickedListener mOnPhraseClickedListener;
    private PhraseStore mPhraseStore;
    private PhrasesAdapter mAdapter;
    private int mTotalHeight;
    private int mNavigationBarInset;
    private int mListBasePaddingBottom;
    private int mEmptyViewBasePaddingBottom;

    private ImageButton mBackKey;
    private ImageButton mAddButton;
    private LinearLayout mChipsRow;
    private RecyclerView mPhraseList;
    private View mEmptyView;
    private TextView mEmptyText;

    private String mCurrentChipId = PhraseStore.CHIP_FAVORITES;

    public PhrasesView(final Context context, final AttributeSet attrs) {
        this(context, attrs, R.attr.emojiPalettesViewStyle);
    }

    public PhrasesView(final Context context, final AttributeSet attrs, final int defStyle) {
        super(context, attrs, defStyle);
        mPhraseStore = PhraseStore.init(context);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        final Resources res = getContext().getResources();
        final int width = ResourceUtils.getKeyboardContentWidth(getContext())
                + getPaddingLeft() + getPaddingRight();
        final int height = (mTotalHeight > 0
                ? mTotalHeight
                : ResourceUtils.getDefaultKeyboardHeight(res)
                        + res.getDimensionPixelSize(R.dimen.config_suggestions_strip_height)
                        + mNavigationBarInset)
                + getPaddingTop() + getPaddingBottom();
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
    }

    /** Total height to occupy — the main keyboard frame's height including the suggestion bar. */
    public void setTotalHeight(final int height) {
        if (height > 0 && height != mTotalHeight) {
            mTotalHeight = height;
            requestLayout();
        }
    }

    public void setNavigationBarInset(final int inset) {
        if (inset == mNavigationBarInset) {
            return;
        }
        mNavigationBarInset = inset;
        mPhraseList.setPadding(mPhraseList.getPaddingLeft(), mPhraseList.getPaddingTop(),
                mPhraseList.getPaddingRight(), mListBasePaddingBottom + inset);
        mEmptyView.setPadding(mEmptyView.getPaddingLeft(), mEmptyView.getPaddingTop(),
                mEmptyView.getPaddingRight(), mEmptyViewBasePaddingBottom + inset);
        requestLayout();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        final int gutter = ResourceUtils.getKeyboardGutterWidth(getContext());
        setPadding(gutter, getPaddingTop(), gutter, getPaddingBottom());
        mBackKey = findViewById(R.id.phrases_back_key);
        mBackKey.setTag(Constants.CODE_ALPHA_FROM_PHRASES);
        mBackKey.setOnTouchListener(this);
        mBackKey.setOnClickListener(this);
        mAddButton = findViewById(R.id.phrases_add_button);
        mAddButton.setOnClickListener(this);
        mChipsRow = findViewById(R.id.phrases_category_chips_row);
        mPhraseList = findViewById(R.id.phrases_list);
        mListBasePaddingBottom = mPhraseList.getPaddingBottom();
        mPhraseList.setLayoutManager(new LinearLayoutManager(getContext()));
        mAdapter = new PhrasesAdapter(this);
        mPhraseList.setAdapter(mAdapter);
        mEmptyView = findViewById(R.id.phrases_empty_view);
        mEmptyViewBasePaddingBottom = mEmptyView.getPaddingBottom();
        mEmptyText = findViewById(R.id.phrases_empty_text);
    }

    public void setKeyboardActionListener(final KeyboardActionListener listener) {
        mKeyboardActionListener = listener;
    }

    public void setOnPhraseClickedListener(final OnPhraseClickedListener listener) {
        mOnPhraseClickedListener = listener;
    }

    public void startPhrases() {
        mPhraseStore.setOnPhrasesChangedListener(this);
        render();
    }

    public void stopPhrases() {
        mPhraseStore.setOnPhrasesChangedListener(null);
    }

    @Override
    public void onPhrasesChanged() {
        post(this::render);
    }

    private void render() {
        renderChips();
        final List<PhraseEntry> entries;
        if (PhraseStore.CHIP_FAVORITES.equals(mCurrentChipId)) {
            entries = mPhraseStore.getFavorites();
        } else if (PhraseStore.CHIP_RECENTS.equals(mCurrentChipId)) {
            entries = mPhraseStore.getRecents();
        } else {
            entries = mPhraseStore.getByCategory(mCurrentChipId);
        }
        if (!entries.isEmpty()) {
            mAdapter.setEntries(entries);
            mPhraseList.setVisibility(VISIBLE);
            mEmptyView.setVisibility(GONE);
            return;
        }
        // Favorites starts empty for a fresh install; land the user on the full
        // first category instead of an empty panel.
        if (PhraseStore.CHIP_FAVORITES.equals(mCurrentChipId)
                && !mPhraseStore.getCategories().isEmpty()) {
            mCurrentChipId = mPhraseStore.getCategories().get(0).mId;
            render();
            return;
        }
        mAdapter.setEntries(entries);
        mPhraseList.setVisibility(GONE);
        mEmptyView.setVisibility(VISIBLE);
        mEmptyText.setText(PhraseStore.CHIP_RECENTS.equals(mCurrentChipId)
                ? R.string.phrases_recents_empty : R.string.phrases_empty);
    }

    private void renderChips() {
        mChipsRow.removeAllViews();
        addChip(PhraseStore.CHIP_FAVORITES, getString(R.string.phrases_chip_favorites));
        addChip(PhraseStore.CHIP_RECENTS, getString(R.string.phrases_chip_recents));
        for (final PhraseStore.Category category : mPhraseStore.getCategories()) {
            addChip(category.mId, category.mLabel);
        }
    }

    private void addChip(final String chipId, final String label) {
        final Context context = getContext();
        final TextView chip = new TextView(context);
        chip.setText(label);
        chip.setTextSize(13);
        chip.setSingleLine(true);
        chip.setPadding(dp(12), dp(6), dp(12), dp(6));
        chip.setBackground(ClipboardHistoryView.createChipBackground(context));
        chip.setAlpha(chipId.equals(mCurrentChipId) ? 1f : 0.55f);
        final LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(dp(6));
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> {
            mCurrentChipId = chipId;
            render();
        });
        mChipsRow.addView(chip);
    }

    private String getString(final int resId) {
        return getContext().getString(resId);
    }

    private int dp(final int value) {
        return (int) (value * getContext().getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public boolean onTouch(final View v, final MotionEvent event) {
        if (event.getActionMasked() != MotionEvent.ACTION_DOWN) {
            return false;
        }
        final Object tag = v.getTag();
        if (!(tag instanceof Integer)) {
            return false;
        }
        mKeyboardActionListener.onPressKey(
                (Integer) tag, 0 /* repeatCount */, true /* isSinglePointer */);
        // Returning false keeps {@link #onClick} and touch-down visual feedback working.
        return false;
    }

    @Override
    public void onClick(final View v) {
        if (v == mAddButton) {
            showPhraseEditor(null /* existing */);
            return;
        }
        final Object tag = v.getTag();
        if (!(tag instanceof Integer)) {
            return;
        }
        final int code = (Integer) tag;
        mKeyboardActionListener.onCodeInput(code, Constants.NOT_A_COORDINATE,
                Constants.NOT_A_COORDINATE, false /* isKeyRepeat */);
        mKeyboardActionListener.onReleaseKey(code, false /* withSliding */);
    }

    @Override
    public void onPhraseClicked(final PhraseEntry entry) {
        if (mOnPhraseClickedListener != null) {
            mOnPhraseClickedListener.onPhraseClicked(entry);
        }
    }

    @Override
    public void onPhraseFavoriteToggled(final PhraseEntry entry) {
        mPhraseStore.toggleFavorite(entry.mId);
    }

    @Override
    public void onPhraseLongClicked(final PhraseEntry entry, final View anchor) {
        final Context context = getContext();
        final List<String> labels = new ArrayList<>();
        labels.add(context.getString(entry.mFavorite
                ? R.string.phrases_unfavorite : R.string.phrases_favorite));
        labels.add(context.getString(R.string.phrases_edit));
        labels.add(context.getString(entry.mBuiltin
                ? R.string.phrases_hide : R.string.phrases_delete));
        final AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle(entry.mText)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which == 0) {
                        mPhraseStore.toggleFavorite(entry.mId);
                    } else if (which == 1) {
                        showPhraseEditor(entry);
                    } else if (which == 2) {
                        mPhraseStore.delete(entry.mId);
                    }
                })
                .create();
        showDialog(dialog, false /* needsTextInput */);
    }

    /**
     * Add-phrase (existing == null) / edit-phrase dialog. Editing a built-in saves
     * a user copy and hides the original, so the list never shows a duplicate
     * (design section 1.2); editing a user phrase updates it in place.
     */
    private void showPhraseEditor(final PhraseEntry existing) {
        final Context context = getContext();
        final List<PhraseStore.Category> categories = mPhraseStore.getCategories();
        final List<String> categoryLabels = new ArrayList<>();
        for (final PhraseStore.Category category : categories) {
            categoryLabels.add(category.mLabel);
        }

        final LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        final int pad = dp(20);
        content.setPadding(pad, dp(8), pad, 0);

        final EditText textField = new EditText(context);
        textField.setSingleLine(false);
        textField.setMinLines(1);
        textField.setMaxLines(3);
        textField.setHint(R.string.phrases_text_hint);
        if (existing != null) {
            textField.setText(existing.mText);
            textField.setSelection(existing.mText.length());
        }
        content.addView(textField);

        final Spinner categorySpinner = new Spinner(context);
        categorySpinner.setAdapter(new ArrayAdapter<>(context,
                android.R.layout.simple_spinner_dropdown_item, categoryLabels));
        int selected = 0;
        final String wantedCategory = existing != null
                ? existing.mCategoryId
                : (PhraseStore.CHIP_FAVORITES.equals(mCurrentChipId)
                        || PhraseStore.CHIP_RECENTS.equals(mCurrentChipId)
                        ? categories.get(0).mId : mCurrentChipId);
        for (int i = 0; i < categories.size(); i++) {
            if (categories.get(i).mId.equals(wantedCategory)) {
                selected = i;
                break;
            }
        }
        categorySpinner.setSelection(selected);
        final LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        spinnerLp.topMargin = dp(12);
        content.addView(categorySpinner, spinnerLp);

        final AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle(existing == null
                        ? R.string.phrases_add_title : R.string.phrases_edit)
                .setView(content)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(existing == null
                        ? R.string.phrases_add_title : R.string.phrases_save, (d, which) -> {
                    final String text = textField.getText().toString().trim();
                    if (text.isEmpty()) {
                        return;
                    }
                    final String categoryId =
                            categories.get(categorySpinner.getSelectedItemPosition()).mId;
                    if (existing == null) {
                        mPhraseStore.add(text, categoryId);
                    } else if (existing.mBuiltin) {
                        mPhraseStore.add(text, categoryId);
                        mPhraseStore.setHidden(existing.mId, true);
                    } else {
                        mPhraseStore.update(existing.mId, text, categoryId);
                    }
                })
                .create();
        showDialog(dialog, true /* needsTextInput */);
    }

    /**
     * Shows a dialog from inside the IME window, mirroring
     * {@code LatinIME.showOptionDialog}: the dialog attaches to this view's
     * window token as an attached dialog. Text-entry dialogs skip
     * FLAG_ALT_FOCUSABLE_IM so the EditText can take input from this keyboard.
     */
    private void showDialog(final Dialog dialog, final boolean needsTextInput) {
        final IBinder windowToken = getWindowToken();
        if (windowToken == null) {
            return;
        }
        final Window window = dialog.getWindow();
        if (window == null) {
            return;
        }
        final WindowManager.LayoutParams lp = window.getAttributes();
        lp.token = windowToken;
        lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;
        window.setAttributes(lp);
        if (!needsTextInput) {
            window.addFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        }
        dialog.show();
    }
}
