/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.inputmethod.keyboard;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodSubtype;

import com.android.inputmethod.event.Event;
import com.android.inputmethod.keyboard.KeyboardLayoutSet.KeyboardLayoutSetException;
import com.android.inputmethod.keyboard.clipboard.ClipboardHistoryView;
import com.android.inputmethod.keyboard.phrases.PhrasesView;
import com.android.inputmethod.keyboard.voice.DictationView;
import com.android.inputmethod.keyboard.emoji.EmojiPalettesView;
import com.android.inputmethod.keyboard.emoji.EmojiSearchController;
import com.android.inputmethod.keyboard.internal.KeyboardState;
import com.android.inputmethod.keyboard.internal.KeyboardTextsSet;
import com.android.inputmethod.latin.InputView;
import org.smc.inputmethod.indic.LatinIME;
import com.android.inputmethod.latin.R;
import com.android.inputmethod.latin.RichInputMethodManager;
import com.android.inputmethod.latin.RichInputMethodSubtype;
import com.android.inputmethod.latin.WordComposer;
import com.android.inputmethod.latin.define.ProductionFlags;
import org.smc.inputmethod.indic.settings.Settings;
import org.smc.inputmethod.indic.settings.SettingsValues;
import com.android.inputmethod.latin.utils.CapsModeUtils;
import com.android.inputmethod.latin.utils.LanguageOnSpacebarUtils;
import com.android.inputmethod.latin.utils.RecapitalizeStatus;
import com.android.inputmethod.latin.utils.ResourceUtils;
import com.android.inputmethod.latin.utils.ScriptUtils;
import com.android.inputmethod.latin.utils.SubtypeLocaleUtils;

import javax.annotation.Nonnull;

public final class KeyboardSwitcher implements KeyboardState.SwitchActions {
    private static final String TAG = KeyboardSwitcher.class.getSimpleName();

    private InputView mCurrentInputView;
    private View mMainKeyboardFrame;
    private MainKeyboardView mKeyboardView;
    private EmojiPalettesView mEmojiPalettesView;
    private ClipboardHistoryView mClipboardHistoryView;
    private PhrasesView mPhrasesView;
    private DictationView mDictationView;
    private LatinIME mLatinIME;
    private RichInputMethodManager mRichImm;
    private boolean mIsHardwareAcceleratedDrawingEnabled;
    private boolean mHardwareKeyboardExpanded;

    public boolean isEmojiSearch = false; // True while the in-keyboard emoji search is showing.
    private KeyboardLayoutSet mSavedKeyboardLayoutSet;

    private KeyboardState mState;

    private KeyboardLayoutSet mKeyboardLayoutSet;
    // TODO: The following {@link KeyboardTextsSet} should be in {@link KeyboardLayoutSet}.
    private final KeyboardTextsSet mKeyboardTextsSet = new KeyboardTextsSet();

    private KeyboardTheme mKeyboardTheme;
    private int mThemeNightMode = Configuration.UI_MODE_NIGHT_UNDEFINED;
    private Context mThemeContext;

    private static final KeyboardSwitcher sInstance = new KeyboardSwitcher();

    public static KeyboardSwitcher getInstance() {
        return sInstance;
    }

    private KeyboardSwitcher() {
        // Intentional empty constructor for singleton.
    }

    public static void init(final LatinIME latinIme) {
        sInstance.initInternal(latinIme);
    }

    private void initInternal(final LatinIME latinIme) {
        mLatinIME = latinIme;
        mRichImm = RichInputMethodManager.getInstance();
        mState = new KeyboardState(this);
        // Hardware accelerated drawing is always enabled since API 21.
        mIsHardwareAcceleratedDrawingEnabled = true;
    }

    public Context getThemeContext() {
        return mThemeContext;
    }

    public void updateKeyboardTheme(@Nonnull Context displayContext) {
        final boolean themeUpdated = updateKeyboardThemeAndContextThemeWrapper(
                displayContext, KeyboardTheme.getKeyboardTheme(displayContext /* context */));
        if (themeUpdated && mKeyboardView != null) {
            mLatinIME.setInputView(
                    onCreateInputView(displayContext, mIsHardwareAcceleratedDrawingEnabled));
        }
    }

    private boolean updateKeyboardThemeAndContextThemeWrapper(final Context context,
            final KeyboardTheme keyboardTheme) {
        final int nightMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        if (mThemeContext == null || !keyboardTheme.equals(mKeyboardTheme)
                || nightMode != mThemeNightMode
                || !mThemeContext.getResources().equals(context.getResources())) {
            mKeyboardTheme = keyboardTheme;
            mThemeNightMode = nightMode;
            mThemeContext = new ContextThemeWrapper(context, keyboardTheme.mStyleId);
            KeyboardLayoutSet.onKeyboardThemeChanged();
            return true;
        }
        return false;
    }

    public void loadKeyboard(final EditorInfo editorInfo, final SettingsValues settingsValues,
            final int currentAutoCapsState, final int currentRecapitalizeState) {
        final KeyboardLayoutSet.Builder builder = new KeyboardLayoutSet.Builder(
                mThemeContext, editorInfo);
        final Resources res = mThemeContext.getResources();
        final int keyboardWidth = ResourceUtils.getKeyboardContentWidth(mThemeContext);
        final int keyboardHeight = ResourceUtils.getKeyboardHeight(res, settingsValues);
        builder.setKeyboardGeometry(keyboardWidth, keyboardHeight);
        builder.setSubtype(mRichImm.getCurrentSubtype());
        builder.setVoiceInputKeyEnabled(settingsValues.mShowsVoiceInputKey);
        builder.setLanguageSwitchKeyEnabled(mLatinIME.shouldShowLanguageSwitchKey());
        builder.setEmojiSwitchKeyEnabled(mLatinIME.shouldShowEmojiSwitchKey());
        builder.setNumberRowEnabled(mLatinIME.shouldShowNumberRow());
        builder.setSplitLayoutEnabledByUser(ProductionFlags.IS_SPLIT_KEYBOARD_SUPPORTED
                && settingsValues.mIsSplitKeyboardEnabled);
        setKeyboardLayoutSet(builder.build());
        try {
            mState.onLoadKeyboard(currentAutoCapsState, currentRecapitalizeState);
            mKeyboardTextsSet.setLocale(mRichImm.getCurrentSubtypeLocale(), mThemeContext);
        } catch (KeyboardLayoutSetException e) {
            Log.w(TAG, "loading keyboard failed: " + e.mKeyboardId, e.getCause());
        }
    }

    public void saveKeyboardState() {
        if (getKeyboard() != null || isShowingEmojiPalettes() || isShowingClipboardHistory()
                || isShowingPhrases() || isShowingOfflineDictation()) {
            mState.onSaveKeyboardState();
        }
    }

    public void onHideWindow() {
        if (mKeyboardView != null) {
            mKeyboardView.onHideWindow();
        }
    }

    private void setKeyboard(
            @Nonnull final int keyboardId,
            @Nonnull final KeyboardSwitchState toggleState) {
        // Make {@link MainKeyboardView} visible and hide {@link EmojiPalettesView}.
        final SettingsValues currentSettingsValues = Settings.getInstance().getCurrent();
        setMainKeyboardFrame(currentSettingsValues, toggleState);
        // TODO: pass this object to setKeyboard instead of getting the current values.
        final MainKeyboardView keyboardView = mKeyboardView;
        final Keyboard oldKeyboard = keyboardView.getKeyboard();
        final Keyboard newKeyboard = mKeyboardLayoutSet.getKeyboard(keyboardId);
        keyboardView.setKeyboard(newKeyboard);
        final boolean wasAlphabet = oldKeyboard == null
                || oldKeyboard.mId.isAlphabetKeyboard();
        if (wasAlphabet != newKeyboard.mId.isAlphabetKeyboard()) {
            mLatinIME.onKeyboardAlphabetnessChanged(newKeyboard.mId.isAlphabetKeyboard());
        }
        mCurrentInputView.setKeyboardTopPadding(newKeyboard.mTopPadding);
        keyboardView.setKeyPreviewPopupEnabled(
                currentSettingsValues.mKeyPreviewPopupOn);
        keyboardView.setKeyPreviewAnimationParams(
                currentSettingsValues.mHasCustomKeyPreviewAnimationParams,
                currentSettingsValues.mKeyPreviewShowUpStartXScale,
                currentSettingsValues.mKeyPreviewShowUpStartYScale,
                currentSettingsValues.mKeyPreviewShowUpDuration,
                currentSettingsValues.mKeyPreviewDismissEndXScale,
                currentSettingsValues.mKeyPreviewDismissEndYScale,
                currentSettingsValues.mKeyPreviewDismissDuration);
        keyboardView.updateShortcutKey(mRichImm.isShortcutImeReady());
        final boolean subtypeChanged = (oldKeyboard == null)
                || !newKeyboard.mId.mSubtype.equals(oldKeyboard.mId.mSubtype);
        int languageOnSpacebarFormatType;
        if (isEmojiSearch) {
            languageOnSpacebarFormatType = LanguageOnSpacebarUtils.FORMAT_TYPE_EMOJI;
        } else {
            languageOnSpacebarFormatType = LanguageOnSpacebarUtils
                    .getLanguageOnSpacebarFormatType(newKeyboard.mId.mSubtype);
        }
        final boolean hasMultipleEnabledIMEsOrSubtypes = mRichImm
                .hasMultipleEnabledIMEsOrSubtypes(true /* shouldIncludeAuxiliarySubtypes */);
        keyboardView.startDisplayLanguageOnSpacebar(subtypeChanged, languageOnSpacebarFormatType,
                hasMultipleEnabledIMEsOrSubtypes);
    }

    public Keyboard getKeyboard() {
        if (mKeyboardView != null) {
            return mKeyboardView.getKeyboard();
        }
        return null;
    }

    public Keyboard getKeyboardForAlphabetElement() {
        if (mKeyboardLayoutSet == null) {
            return null;
        }
        return mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET);
    }

    public Keyboard getKeyboardForShiftedElement() {
        if (mKeyboardLayoutSet == null) {
            return null;
        }
        return mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED);
    }

    private void setKeyboardLayoutSet(final KeyboardLayoutSet keyboardLayoutSet) {
        mKeyboardLayoutSet = keyboardLayoutSet;
        mLatinIME.invalidateHardwareInscriptMap();
    }

    // TODO: Remove this method. Come up with a more comprehensive way to reset the keyboard layout
    // when a keyboard layout set doesn't get reloaded in LatinIME.onStartInputViewInternal().
    public void resetKeyboardStateToAlphabet(final int currentAutoCapsState,
            final int currentRecapitalizeState) {
        mState.onResetKeyboardStateToAlphabet(currentAutoCapsState, currentRecapitalizeState);
    }

    public void onPressKey(final int code, final boolean isSinglePointer,
            final int currentAutoCapsState, final int currentRecapitalizeState) {
        mState.onPressKey(code, isSinglePointer, currentAutoCapsState, currentRecapitalizeState);
    }

    public void onReleaseKey(final int code, final boolean withSliding,
            final int currentAutoCapsState, final int currentRecapitalizeState) {
        mState.onReleaseKey(code, withSliding, currentAutoCapsState, currentRecapitalizeState);
    }

    public void onFinishSlidingInput(final int currentAutoCapsState,
            final int currentRecapitalizeState) {
        mState.onFinishSlidingInput(currentAutoCapsState, currentRecapitalizeState);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setAlphabetKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setAlphabetKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_ALPHABET, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setAlphabetManualShiftedKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setAlphabetManualShiftedKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setAlphabetAutomaticShiftedKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setAlphabetAutomaticShiftedKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_ALPHABET_AUTOMATIC_SHIFTED, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setAlphabetShiftLockedKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setAlphabetShiftLockedKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setAlphabetShiftLockShiftedKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setAlphabetShiftLockShiftedKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCK_SHIFTED, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setSymbolsKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setSymbolsKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_SYMBOLS, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setNumericPadKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setNumericPadKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_NUMERIC_PAD, KeyboardSwitchState.HIDDEN);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setSymbolsShiftedKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setSymbolsShiftedKeyboard");
        }
        setKeyboard(KeyboardId.ELEMENT_SYMBOLS_SHIFTED, KeyboardSwitchState.SYMBOLS_SHIFTED);
    }

    public void setHardwareKeyboardExpanded(final boolean expanded) {
        mHardwareKeyboardExpanded = expanded;
    }

    public boolean isHardwareKeyboardExpanded() {
        return mHardwareKeyboardExpanded;
    }

    public boolean isImeSuppressedByHardwareKeyboard(
            @Nonnull final SettingsValues settingsValues,
            @Nonnull final KeyboardSwitchState toggleState) {
        return settingsValues.mHasHardwareKeyboard && !mHardwareKeyboardExpanded
                && toggleState == KeyboardSwitchState.HIDDEN;
    }

    private void setMainKeyboardFrame(
            @Nonnull final SettingsValues settingsValues,
            @Nonnull final KeyboardSwitchState toggleState) {
        final boolean wasShowingPanel = isShowingEmojiPalettes() || isShowingClipboardHistory()
                || isShowingPhrases() || isShowingOfflineDictation();
        // {@link #mMainKeyboardFrame} also contains the suggestion strip (see
        // main_keyboard_frame.xml), so it must stay VISIBLE here even when the hardware-keyboard
        // suppression hides {@link #mKeyboardView} alone; only setEmojiKeyboard()/
        // setClipboardKeyboard() take the whole frame GONE, when an alternate panel replaces it.
        mMainKeyboardFrame.setVisibility(View.VISIBLE);
        mKeyboardView.setVisibility(isImeSuppressedByHardwareKeyboard(settingsValues, toggleState)
                ? View.GONE : View.VISIBLE);
        mEmojiPalettesView.setVisibility(View.GONE);
        mEmojiPalettesView.stopEmojiPalettes();
        mClipboardHistoryView.setVisibility(View.GONE);
        mClipboardHistoryView.stopClipboardHistory();
        mPhrasesView.setVisibility(View.GONE);
        mPhrasesView.stopPhrases();
        mDictationView.setVisibility(View.GONE);
        mDictationView.stopDictation();
        if (wasShowingPanel) {
            // Leaving the emoji palette or clipboard panel: drop any leftover suggestions.
            mLatinIME.clearSuggestionStrip();
        }
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setEmojiKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setEmojiKeyboard");
        }
        final Keyboard keyboard = mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET);
        mMainKeyboardFrame.setVisibility(View.GONE);
        // The visibility of {@link #mKeyboardView} must be aligned with {@link #MainKeyboardFrame}.
        // @see #getVisibleKeyboardView() and
        // @see LatinIME#onComputeInset(android.inputmethodservice.InputMethodService.Insets)
        mKeyboardView.setVisibility(View.GONE);
        mPhrasesView.setVisibility(View.GONE);
        mPhrasesView.stopPhrases();
        mDictationView.setVisibility(View.GONE);
        mDictationView.stopDictation();
        mEmojiPalettesView.setMainKeyboardHeight(keyboard.mOccupiedHeight);
        mEmojiPalettesView.startEmojiPalettes(
                mKeyboardTextsSet.getText(KeyboardTextsSet.SWITCH_TO_ALPHA_KEY_LABEL),
                mKeyboardView.getKeyVisualAttribute(), keyboard.mIconsSet);
        mEmojiPalettesView.setVisibility(View.VISIBLE);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setClipboardKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setClipboardKeyboard");
        }
        final Keyboard keyboard = mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET);
        // Prefer the frame's real height (keyboard + suggestion bar) while it is still laid out.
        final int frameHeight = mMainKeyboardFrame.getHeight();
        mMainKeyboardFrame.setVisibility(View.GONE);
        // The visibility of {@link #mKeyboardView} must be aligned with {@link #MainKeyboardFrame}.
        // @see #getVisibleKeyboardView() and
        // @see LatinIME#onComputeInset(android.inputmethodservice.InputMethodService.Insets)
        mKeyboardView.setVisibility(View.GONE);
        mEmojiPalettesView.setVisibility(View.GONE);
        mEmojiPalettesView.stopEmojiPalettes();
        mPhrasesView.setVisibility(View.GONE);
        mPhrasesView.stopPhrases();
        mDictationView.setVisibility(View.GONE);
        mDictationView.stopDictation();
        mClipboardHistoryView.setTotalHeight(frameHeight > 0 ? frameHeight
                : keyboard.mOccupiedHeight + mKeyboardView.getPaddingBottom()
                        + mThemeContext.getResources()
                                .getDimensionPixelSize(R.dimen.config_suggestions_strip_height));
        mClipboardHistoryView.startClipboardHistory();
        mClipboardHistoryView.setVisibility(View.VISIBLE);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void setPhrasesKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setPhrasesKeyboard");
        }
        final Keyboard keyboard = mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET);
        // Prefer the frame's real height (keyboard + suggestion bar) while it is still laid out.
        final int frameHeight = mMainKeyboardFrame.getHeight();
        mMainKeyboardFrame.setVisibility(View.GONE);
        // The visibility of {@link #mKeyboardView} must be aligned with {@link #MainKeyboardFrame}.
        mKeyboardView.setVisibility(View.GONE);
        mEmojiPalettesView.setVisibility(View.GONE);
        mEmojiPalettesView.stopEmojiPalettes();
        mClipboardHistoryView.setVisibility(View.GONE);
        mClipboardHistoryView.stopClipboardHistory();
        mDictationView.setVisibility(View.GONE);
        mDictationView.stopDictation();
        mPhrasesView.setTotalHeight(frameHeight > 0 ? frameHeight
                : keyboard.mOccupiedHeight + mKeyboardView.getPaddingBottom()
                        + mThemeContext.getResources()
                                .getDimensionPixelSize(R.dimen.config_suggestions_strip_height));
        mPhrasesView.startPhrases();
        mPhrasesView.setVisibility(View.VISIBLE);
    }

    /**
     * Shows the offline Urdu dictation panel. Driven directly by LatinIME (the
     * mic key carries no dedicated key code), not by {@link KeyboardState}.
     */
    public void setOfflineDictationKeyboard() {
        if (DEBUG_ACTION) {
            Log.d(TAG, "setOfflineDictationKeyboard");
        }
        final Keyboard keyboard = mKeyboardLayoutSet.getKeyboard(KeyboardId.ELEMENT_ALPHABET);
        final int frameHeight = mMainKeyboardFrame.getHeight();
        mMainKeyboardFrame.setVisibility(View.GONE);
        mKeyboardView.setVisibility(View.GONE);
        mEmojiPalettesView.setVisibility(View.GONE);
        mEmojiPalettesView.stopEmojiPalettes();
        mClipboardHistoryView.setVisibility(View.GONE);
        mClipboardHistoryView.stopClipboardHistory();
        mPhrasesView.setVisibility(View.GONE);
        mPhrasesView.stopPhrases();
        mDictationView.setTotalHeight(frameHeight > 0 ? frameHeight
                : keyboard.mOccupiedHeight + mKeyboardView.getPaddingBottom()
                        + mThemeContext.getResources()
                                .getDimensionPixelSize(R.dimen.config_suggestions_strip_height));
        mDictationView.startDictation();
        mDictationView.setVisibility(View.VISIBLE);
    }

    public void setEmojiSearchController(final EmojiSearchController controller) {
        if (mEmojiPalettesView != null) {
            mEmojiPalettesView.setEmojiSearchController(controller);
        }
    }

    /**
     * Show an English qwerty keyboard for the in-keyboard emoji search without persistently
     * changing the user's subtype. The real layout set is saved and restored on exit.
     */
    public void setEmojiSearchKeyboard() {
        if (!isEmojiSearch) {
            mSavedKeyboardLayoutSet = mKeyboardLayoutSet;
            setKeyboardLayoutSet(buildEmojiSearchLayoutSet());
            isEmojiSearch = true;
            if (mKeyboardView != null) {
                mKeyboardView.setGestureHandlingEnabledByUser(false /* inputEnabled */,
                        false /* trailEnabled */, false /* floatingPreviewEnabled */);
            }
        }
        resetKeyboardStateToAlphabet(WordComposer.CAPS_MODE_OFF,
                RecapitalizeStatus.NOT_A_RECAPITALIZE_MODE);
    }

    public void restoreFromEmojiSearch() {
        if (isEmojiSearch) {
            setKeyboardLayoutSet(mSavedKeyboardLayoutSet);
            mSavedKeyboardLayoutSet = null;
            isEmojiSearch = false;
            final SettingsValues settingsValues = Settings.getInstance().getCurrent();
            if (mKeyboardView != null) {
                mKeyboardView.setGestureHandlingEnabledByUser(
                        settingsValues.mGestureInputEnabled,
                        settingsValues.mGestureTrailEnabled,
                        settingsValues.mGestureFloatingPreviewTextEnabled);
            }
        }
    }

    public void exitEmojiSearchKeyboard() {
        restoreFromEmojiSearch();
        mState.onExitEmojiSearch();
    }

    private KeyboardLayoutSet buildEmojiSearchLayoutSet() {
        final SettingsValues settingsValues = Settings.getInstance().getCurrent();
        final KeyboardLayoutSet.Builder builder = new KeyboardLayoutSet.Builder(
                mThemeContext, mLatinIME.getCurrentInputEditorInfo());
        final Resources res = mThemeContext.getResources();
        builder.setKeyboardGeometry(ResourceUtils.getKeyboardContentWidth(mThemeContext),
                ResourceUtils.getKeyboardHeight(res, settingsValues));
        builder.setSubtype(RichInputMethodSubtype.getEmojiSearchSubtype());
        builder.setVoiceInputKeyEnabled(false);
        builder.setLanguageSwitchKeyEnabled(false);
        builder.setEmojiSwitchKeyEnabled(false);
        builder.setNumberRowEnabled(mLatinIME.shouldShowNumberRow());
        builder.setSplitLayoutEnabledByUser(ProductionFlags.IS_SPLIT_KEYBOARD_SUPPORTED
                && settingsValues.mIsSplitKeyboardEnabled);
        return builder.build();
    }

    public enum KeyboardSwitchState {
        HIDDEN(-1),
        SYMBOLS_SHIFTED(KeyboardId.ELEMENT_SYMBOLS_SHIFTED),
        EMOJI(KeyboardId.ELEMENT_EMOJI_RECENTS),
        OTHER(-1);

        final int mKeyboardId;

        KeyboardSwitchState(int keyboardId) {
            mKeyboardId = keyboardId;
        }
    }

    public KeyboardSwitchState getKeyboardSwitchState() {
        boolean hidden = !isShowingEmojiPalettes()
                && !isShowingClipboardHistory()
                && !isShowingPhrases()
                && !isShowingOfflineDictation()
                && (mKeyboardLayoutSet == null
                || mKeyboardView == null
                || !mKeyboardView.isShown());
        KeyboardSwitchState state;
        if (hidden) {
            return KeyboardSwitchState.HIDDEN;
        } else if (isShowingEmojiPalettes()) {
            return KeyboardSwitchState.EMOJI;
        } else if (isShowingKeyboardId(KeyboardId.ELEMENT_SYMBOLS_SHIFTED)) {
            return KeyboardSwitchState.SYMBOLS_SHIFTED;
        }
        return KeyboardSwitchState.OTHER;
    }

    public void onToggleKeyboard(@Nonnull final KeyboardSwitchState toggleState) {
        KeyboardSwitchState currentState = getKeyboardSwitchState();
        Log.w(TAG, "onToggleKeyboard() : Current = " + currentState + " : Toggle = " + toggleState);
        if (currentState == toggleState) {
            mLatinIME.stopShowingInputView();
            mLatinIME.hideWindow();
            setAlphabetKeyboard();
        } else {
            mLatinIME.startShowingInputView(true);
            if (toggleState == KeyboardSwitchState.EMOJI) {
                setEmojiKeyboard();
            } else {
                mEmojiPalettesView.stopEmojiPalettes();
                mEmojiPalettesView.setVisibility(View.GONE);
                mClipboardHistoryView.stopClipboardHistory();
                mClipboardHistoryView.setVisibility(View.GONE);
                mPhrasesView.stopPhrases();
                mPhrasesView.setVisibility(View.GONE);
                mDictationView.stopDictation();
                mDictationView.setVisibility(View.GONE);

                mMainKeyboardFrame.setVisibility(View.VISIBLE);
                mKeyboardView.setVisibility(View.VISIBLE);
                setKeyboard(toggleState.mKeyboardId, toggleState);
            }
        }
    }

    // Future method for requesting an updating to the shift state.
    @Override
    public void requestUpdatingShiftState(final int autoCapsFlags, final int recapitalizeMode) {
        if (DEBUG_ACTION) {
            Log.d(TAG, "requestUpdatingShiftState: "
                    + " autoCapsFlags=" + CapsModeUtils.flagsToString(autoCapsFlags)
                    + " recapitalizeMode=" + RecapitalizeStatus.modeToString(recapitalizeMode));
        }
        mState.onUpdateShiftState(autoCapsFlags, recapitalizeMode);
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void startDoubleTapShiftKeyTimer() {
        if (DEBUG_TIMER_ACTION) {
            Log.d(TAG, "startDoubleTapShiftKeyTimer");
        }
        final MainKeyboardView keyboardView = getMainKeyboardView();
        if (keyboardView != null) {
            keyboardView.startDoubleTapShiftKeyTimer();
        }
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public void cancelDoubleTapShiftKeyTimer() {
        if (DEBUG_TIMER_ACTION) {
            Log.d(TAG, "setAlphabetKeyboard");
        }
        final MainKeyboardView keyboardView = getMainKeyboardView();
        if (keyboardView != null) {
            keyboardView.cancelDoubleTapShiftKeyTimer();
        }
    }

    // Implements {@link KeyboardState.SwitchActions}.
    @Override
    public boolean isInDoubleTapShiftKeyTimeout() {
        if (DEBUG_TIMER_ACTION) {
            Log.d(TAG, "isInDoubleTapShiftKeyTimeout");
        }
        final MainKeyboardView keyboardView = getMainKeyboardView();
        return keyboardView != null && keyboardView.isInDoubleTapShiftKeyTimeout();
    }

    /**
     * Updates state machine to figure out when to automatically switch back to the previous mode.
     */
    public void onEvent(final Event event, final int currentAutoCapsState,
            final int currentRecapitalizeState) {
        mState.onEvent(event, currentAutoCapsState, currentRecapitalizeState);
    }

    public boolean isShowingKeyboardId(@Nonnull int... keyboardIds) {
        if (mKeyboardView == null || !mKeyboardView.isShown()) {
            return false;
        }
        int activeKeyboardId = mKeyboardView.getKeyboard().mId.mElementId;
        for (int keyboardId : keyboardIds) {
            if (activeKeyboardId == keyboardId) {
                return true;
            }
        }
        return false;
    }

    public boolean isShowingEmojiPalettes() {
        return mEmojiPalettesView != null && mEmojiPalettesView.isShown();
    }

    public boolean isShowingClipboardHistory() {
        return mClipboardHistoryView != null && mClipboardHistoryView.isShown();
    }

    public boolean isShowingPhrases() {
        return mPhrasesView != null && mPhrasesView.isShown();
    }

    public boolean isShowingOfflineDictation() {
        return mDictationView != null && mDictationView.isShown();
    }

    public boolean isShowingMoreKeysPanel() {
        if (isShowingEmojiPalettes() || isShowingClipboardHistory()
                || isShowingPhrases() || isShowingOfflineDictation()) {
            return false;
        }
        return mKeyboardView.isShowingMoreKeysPanel();
    }

    public View getVisibleKeyboardView() {
        if (isShowingEmojiPalettes()) {
            return mEmojiPalettesView;
        }
        if (isShowingClipboardHistory()) {
            return mClipboardHistoryView;
        }
        if (isShowingPhrases()) {
            return mPhrasesView;
        }
        if (isShowingOfflineDictation()) {
            return mDictationView;
        }
        return mKeyboardView;
    }

    public MainKeyboardView getMainKeyboardView() {
        return mKeyboardView;
    }

    public void deallocateMemory() {
        if (mKeyboardView != null) {
            mKeyboardView.cancelAllOngoingEvents();
            mKeyboardView.deallocateMemory();
        }
        if (mEmojiPalettesView != null) {
            mEmojiPalettesView.stopEmojiPalettes();
        }
        if (mClipboardHistoryView != null) {
            mClipboardHistoryView.stopClipboardHistory();
        }
        if (mPhrasesView != null) {
            mPhrasesView.stopPhrases();
        }
        if (mDictationView != null) {
            mDictationView.stopDictation();
        }
    }

    public View onCreateInputView(@Nonnull Context displayContext,
            final boolean isHardwareAcceleratedDrawingEnabled) {
        if (mKeyboardView != null) {
            mKeyboardView.closing();
        }

        updateKeyboardThemeAndContextThemeWrapper(
                displayContext, KeyboardTheme.getKeyboardTheme(displayContext /* context */));
        mCurrentInputView = (InputView)LayoutInflater.from(mThemeContext).inflate(
                R.layout.input_view, null);
        mMainKeyboardFrame = mCurrentInputView.findViewById(R.id.main_keyboard_frame);
        mEmojiPalettesView = (EmojiPalettesView)mCurrentInputView.findViewById(
                R.id.emoji_palettes_view);

        mKeyboardView = (MainKeyboardView) mCurrentInputView.findViewById(R.id.keyboard_view);
        mKeyboardView.setHardwareAcceleratedDrawingEnabled(isHardwareAcceleratedDrawingEnabled);
        mKeyboardView.setKeyboardActionListener(mLatinIME);
        final int gutter = ResourceUtils.getKeyboardGutterWidth(mThemeContext);
        mKeyboardView.setPadding(gutter, mKeyboardView.getPaddingTop(),
                gutter, mKeyboardView.getPaddingBottom());
        mEmojiPalettesView.setHardwareAcceleratedDrawingEnabled(
                isHardwareAcceleratedDrawingEnabled);
        mEmojiPalettesView.setKeyboardActionListener(mLatinIME);
        mClipboardHistoryView = (ClipboardHistoryView) mCurrentInputView.findViewById(
                R.id.clipboard_history_view);
        mClipboardHistoryView.setKeyboardActionListener(mLatinIME);
        mClipboardHistoryView.setOnClipboardEntryClickedListener(mLatinIME);
        mPhrasesView = (PhrasesView) mCurrentInputView.findViewById(R.id.phrases_view);
        mPhrasesView.setKeyboardActionListener(mLatinIME);
        mPhrasesView.setOnPhraseClickedListener(mLatinIME);
        mDictationView = (DictationView) mCurrentInputView.findViewById(R.id.dictation_view);
        mDictationView.setOnDictationListener(mLatinIME);
        return mCurrentInputView;
    }

    public int getKeyboardShiftMode() {
        final Keyboard keyboard = getKeyboard();
        if (keyboard == null) {
            return WordComposer.CAPS_MODE_OFF;
        }
        switch (keyboard.mId.mElementId) {
        case KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED:
        case KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCK_SHIFTED:
            return WordComposer.CAPS_MODE_MANUAL_SHIFT_LOCKED;
        case KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED:
            return WordComposer.CAPS_MODE_MANUAL_SHIFTED;
        case KeyboardId.ELEMENT_ALPHABET_AUTOMATIC_SHIFTED:
            return WordComposer.CAPS_MODE_AUTO_SHIFTED;
        default:
            return WordComposer.CAPS_MODE_OFF;
        }
    }

    public int getCurrentKeyboardScriptId() {
        if (null == mKeyboardLayoutSet) {
            return ScriptUtils.SCRIPT_UNKNOWN;
        }
        return mKeyboardLayoutSet.getScriptId();
    }

    public void refreshRecentEmojis() {
        mEmojiPalettesView.refreshRecentEmojis();
    }
}
