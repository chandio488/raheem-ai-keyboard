/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.content.Context;
import android.util.Log;

import com.android.inputmethod.latin.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

/**
 * Name Correction Layer (Farhan reply 12, 2026-11-14 — final ruling for the
 * single update). sherpa-onnx hotwords do not exist for Moonshine models
 * (transducer-only), so known mis-heard proper names are corrected AFTER
 * decode and BEFORE the dictation preview, from the small editable rule
 * list in {@code R.raw.name_corrections}:
 *
 * <ul>
 *   <li>Rules without context always fire (the wrong form is not a real
 *       Urdu word: فرانک، منھنا).</li>
 *   <li>Rules with {@code contextAny} fire only when the utterance itself
 *       carries one of the context words (فرانس is also a country name —
 *       it is corrected to فرحان only in friend/brother conversation).</li>
 *   <li>Rules with {@code contextNone} never fire when a guard phrase is
 *       present (منع is also a real word: «منع ہے» must survive).</li>
 *   <li>Numbers, prices, units, English words and اعراب are never touched —
 *       only the exact listed name forms are replaced.</li>
 *   <li>The raw ASR text is preserved by the caller; every change is
 *       reported in {@link Result#mNote} so the panel can announce it and
 *       the user approves the corrected preview before insertion.</li>
 * </ul>
 * Everything is local and offline; the rule list is plain JSON so new names
 * can be added without code changes.
 */
public final class NameCorrector {
    private static final String TAG = NameCorrector.class.getSimpleName();

    public static final class Result {
        /** Text to preview/insert (corrected when a rule fired). */
        public final String mText;
        /** Human-readable change note for the panel, or null when unchanged. */
        @Nullable public final String mNote;

        Result(final String text, @Nullable final String note) {
            mText = text;
            mNote = note;
        }
    }

    private static final class Rule {
        final String mWrong;
        final String mRight;
        final List<String> mContextAny = new ArrayList<>();
        final List<String> mContextNone = new ArrayList<>();

        Rule(final String wrong, final String right) {
            mWrong = wrong;
            mRight = right;
        }
    }

    private static List<Rule> sRules;

    private NameCorrector() {
        // Utility class.
    }

    public static Result correct(final Context context, final String rawText) {
        if (rawText == null || rawText.isEmpty()) {
            return new Result(rawText, null);
        }
        // v1.5 foundation (Farhan reply 25): NFC normalization FIRST, on
        // text this keyboard controls (its own offline dictation result).
        // NFC composes decomposed sequences into single letters — ا plus
        // U+0653 MADDAH ABOVE becomes آ (U+0622), ا plus U+0654 becomes
        // أ, ا plus U+0655 becomes إ — so a maddah the recognizer emitted
        // as a loose combining mark lands as the proper letter. This is
        // deterministic Unicode composition only: no word is guessed,
        // and اپ is never blindly rewritten to آپ (context rules below
        // remain the only word-level corrections, as before).
        final String normalized = Normalizer.normalize(rawText, Normalizer.Form.NFC);
        final boolean compositionChanged = !normalized.equals(rawText);
        final List<Rule> rules = loadRules(context);
        String text = normalized;
        final List<String> changes = new ArrayList<>();
        for (final Rule rule : rules) {
            if (!text.contains(rule.mWrong)) {
                continue;
            }
            if (!rule.mContextAny.isEmpty() && !containsAny(text, rule.mContextAny)) {
                continue;
            }
            if (!rule.mContextNone.isEmpty() && containsAny(text, rule.mContextNone)) {
                continue;
            }
            text = text.replace(rule.mWrong, rule.mRight);
            changes.add(rule.mWrong + " ← " + rule.mRight);
        }
        if (changes.isEmpty() && !compositionChanged) {
            return new Result(rawText, null);
        }
        if (changes.isEmpty()) {
            return new Result(text, "متن درست کیا گیا: اعراب کی ترکیب");
        }
        final StringBuilder note = new StringBuilder("نام درست کیا گیا: ");
        for (int i = 0; i < changes.size(); i++) {
            if (i > 0) {
                note.append("، ");
            }
            note.append(changes.get(i));
        }
        if (compositionChanged) {
            note.append("؛ اعراب کی ترکیب بھی درست کی گئی");
        }
        return new Result(text, note.toString());
    }

    private static boolean containsAny(final String text, final List<String> words) {
        for (final String word : words) {
            if (text.contains(word)) {
                return true;
            }
        }
        return false;
    }

    private static synchronized List<Rule> loadRules(final Context context) {
        if (sRules != null) {
            return sRules;
        }
        final List<Rule> rules = new ArrayList<>();
        try (InputStream in = context.getResources().openRawResource(R.raw.name_corrections)) {
            final byte[] bytes = new byte[in.available()];
            int offset = 0;
            while (offset < bytes.length) {
                final int read = in.read(bytes, offset, bytes.length - offset);
                if (read < 0) {
                    break;
                }
                offset += read;
            }
            final JSONObject root =
                    new JSONObject(new String(bytes, 0, offset, StandardCharsets.UTF_8));
            final JSONArray array = root.getJSONArray("rules");
            for (int i = 0; i < array.length(); i++) {
                final JSONObject entry = array.getJSONObject(i);
                final Rule rule = new Rule(entry.getString("wrong"), entry.getString("right"));
                readStringArray(entry, "contextAny", rule.mContextAny);
                readStringArray(entry, "contextNone", rule.mContextNone);
                rules.add(rule);
            }
        } catch (final Exception e) {
            Log.w(TAG, "Could not load name corrections", e);
            rules.clear();
        }
        sRules = rules;
        return sRules;
    }

    private static void readStringArray(final JSONObject entry, final String key,
            final List<String> out) throws Exception {
        final JSONArray array = entry.optJSONArray(key);
        if (array == null) {
            return;
        }
        for (int i = 0; i < array.length(); i++) {
            out.add(array.getString(i));
        }
    }
}
