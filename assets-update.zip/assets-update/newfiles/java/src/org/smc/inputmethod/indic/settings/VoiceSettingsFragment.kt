/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.settings

import android.os.Bundle

import com.android.inputmethod.latin.R

/**
 * Voice input settings (RAHEEM AI ULTRA v1.5, Farhan reply 25): the user
 * can pin the mic-key engine by hand — Auto (hybrid routing), Google
 * Voice Typing, or the built-in offline Urdu panel — and can turn the
 * offline Urdu feature off entirely. The static screen comes from
 * prefs_screen_voice.xml; the values are read on every mic tap by
 * org.smc.inputmethod.indic.voice.OfflineVoiceRouter.
 */
class VoiceSettingsFragment : SubScreenFragment() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        super.onCreatePreferences(savedInstanceState, rootKey)
        addPreferencesFromResource(R.xml.prefs_screen_voice)
    }
}
