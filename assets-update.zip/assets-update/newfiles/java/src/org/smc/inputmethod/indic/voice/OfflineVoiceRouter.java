/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.content.Context;

import com.android.inputmethod.compat.PreferenceManagerCompat;
import com.android.inputmethod.latin.RichInputMethodManager;

import java.util.Locale;

/**
 * Routing predicate for the mic key (RAHEEM AI ULTRA update, design section 2.2).
 *
 * <p>The offline Urdu dictation panel is used only when ALL of these hold:
 * <ul>
 *   <li>the native recognizer is linked into this build
 *       ({@link UrduAsrEngine#isNativeLinked()}),</li>
 *   <li>the user has not turned the feature off
 *       ({@link #PREF_OFFLINE_VOICE_URDU_ENABLED}, default ON),</li>
 *   <li>the current subtype's language is Urdu (Navees, NLA or transliteration).</li>
 * </ul>
 * In every other case the mic key keeps today's behaviour — switching to the
 * system's shortcut (voice) IME — untouched.
 */
public final class OfflineVoiceRouter {
    public static final String PREF_OFFLINE_VOICE_URDU_ENABLED = "offline_voice_urdu_enabled";

    private OfflineVoiceRouter() {
        // Utility class.
    }

    public static boolean shouldUseOfflineUrdu(final Context context) {
        if (!UrduAsrEngine.isNativeLinked()) {
            return false;
        }
        final boolean enabled = PreferenceManagerCompat.getDeviceSharedPreferences(context)
                .getBoolean(PREF_OFFLINE_VOICE_URDU_ENABLED, true /* defaultValue */);
        if (!enabled) {
            return false;
        }
        final Locale locale = RichInputMethodManager.getInstance().getCurrentSubtypeLocale();
        return locale != null && "ur".equals(locale.getLanguage());
    }
}
