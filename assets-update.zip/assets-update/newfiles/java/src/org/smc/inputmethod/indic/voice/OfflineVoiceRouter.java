/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.voice;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;

import com.android.inputmethod.compat.PreferenceManagerCompat;
import com.android.inputmethod.latin.RichInputMethodManager;

import java.util.List;
import java.util.Locale;

/**
 * Routing predicate for the mic key (RAHEEM AI ULTRA).
 *
 * <p>v1.5 routing (Farhan reply 25, 2026-11-15 — final ruling after the
 * owner's v1.4 phone test): the v1.3 rule required
 * {@code NET_CAPABILITY_VALIDATED} before the online route could win.
 * On the owner's phone the offline panel opened although a working
 * mobile network was present: on mobile networks VALIDATED can read
 * false for reasons outside the user's control (carrier validation
 * probes, VPN / Private DNS, network hand-over), so a correct network
 * was misjudged as offline. Reply 25 reverses reply 21's condition:
 * VALIDATED is no longer a routing requirement — the decision uses the
 * INTERNET capability alone, and Google Voice judges its own network
 * state once open. The user can also pin the engine by hand in
 * Settings ({@link #PREF_VOICE_MODE}):
 * <ul>
 *   <li>{@code auto} (default): Google Voice Typing (legacy shortcut
 *       route) when an internet-capable network is up and a voice input
 *       method is enabled; otherwise the offline Urdu panel.</li>
 *   <li>{@code google}: always the legacy shortcut route.</li>
 *   <li>{@code shruti}: always the offline Urdu panel.</li>
 * </ul>
 * The offline panel itself is used only when the native recognizer is
 * linked into this build ({@link UrduAsrEngine#isNativeLinked()}), the
 * user has not turned the feature off
 * ({@link #PREF_OFFLINE_VOICE_URDU_ENABLED}, default ON) and the current
 * subtype's language is Urdu (Navees, NLA or transliteration).
 * The decision is re-made on every mic tap. Any failure while probing
 * the network or the input method list resolves to the offline panel,
 * which always works.
 */
public final class OfflineVoiceRouter {
    public static final String PREF_OFFLINE_VOICE_URDU_ENABLED = "offline_voice_urdu_enabled";
    public static final String PREF_VOICE_MODE = "voice_input_mode";
    public static final String VOICE_MODE_AUTO = "auto";
    public static final String VOICE_MODE_GOOGLE = "google";
    public static final String VOICE_MODE_SHRUTI = "shruti";

    private OfflineVoiceRouter() {
        // Utility class.
    }

    public static boolean shouldUseOfflineUrdu(final Context context) {
        if (!UrduAsrEngine.isNativeLinked()) {
            return false;
        }
        final android.content.SharedPreferences prefs =
                PreferenceManagerCompat.getDeviceSharedPreferences(context);
        final boolean enabled =
                prefs.getBoolean(PREF_OFFLINE_VOICE_URDU_ENABLED, true /* defaultValue */);
        if (!enabled) {
            return false;
        }
        final Locale locale = RichInputMethodManager.getInstance().getCurrentSubtypeLocale();
        if (locale == null || !"ur".equals(locale.getLanguage())) {
            return false;
        }
        final String mode = prefs.getString(PREF_VOICE_MODE, VOICE_MODE_AUTO);
        if (VOICE_MODE_SHRUTI.equals(mode)) {
            return true;
        }
        if (VOICE_MODE_GOOGLE.equals(mode)) {
            return false;
        }
        // Auto: online (INTERNET capability) + a voice IME present ->
        // Google route wins. VALIDATED is deliberately NOT required
        // (Farhan reply 25).
        if (isNetworkConnected(context) && hasVoiceInputMethod(context)) {
            return false;
        }
        return true;
    }

    private static boolean isNetworkConnected(final Context context) {
        try {
            final ConnectivityManager cm = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                final Network network = cm.getActiveNetwork();
                if (network == null) {
                    return false;
                }
                final NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                // Farhan reply 25: INTERNET capability alone decides.
                // NET_CAPABILITY_VALIDATED must not gate the online
                // route — on mobile networks it can read false while
                // the connection actually works, which is exactly the
                // v1.4 phone-test failure.
                return caps != null
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            }
            @SuppressWarnings("deprecation")
            final NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (final Exception e) {
            // Permission or platform failure: report "offline" so the
            // built-in panel is used instead of a dead end.
            return false;
        }
    }

    private static boolean hasVoiceInputMethod(final Context context) {
        try {
            final InputMethodManager imm = (InputMethodManager)
                    context.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return false;
            }
            final List<InputMethodInfo> list = imm.getEnabledInputMethodList();
            for (final InputMethodInfo info : list) {
                final int count = info.getSubtypeCount();
                for (int i = 0; i < count; i++) {
                    final InputMethodSubtype subtype = info.getSubtypeAt(i);
                    if (subtype != null && "voice".equals(subtype.getMode())) {
                        return true;
                    }
                }
            }
            return false;
        } catch (final Exception e) {
            return false;
        }
    }
}
