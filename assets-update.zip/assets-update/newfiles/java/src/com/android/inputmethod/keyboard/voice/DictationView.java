/*
 * Copyright 2026 Raheem AI ULTRA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.inputmethod.keyboard.voice;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.inputmethod.keyboard.clipboard.ClipboardHistoryView;
import com.android.inputmethod.latin.R;
import com.android.inputmethod.latin.utils.ResourceUtils;

import org.smc.inputmethod.indic.voice.OfflineVoiceManager;
import org.smc.inputmethod.indic.voice.UrduAsrEngine;

/**
 * Offline Urdu dictation panel (RAHEEM AI ULTRA update, design section 2.2).
 *
 * <p>Opened by LatinIME (not by KeyboardState — the mic key has no key code of
 * its own) when the Urdu offline route applies. State machine:
 * NO_MODEL (download offer) → DOWNLOADING (per-file progress, cancel) →
 * READY (big mic) → LISTENING (level meter, stop/cancel) → PROCESSING →
 * RESULT (preview; insert / retry / discard). Recognised text is committed
 * only from the RESULT state's insert button — at this model's conversational
 * accuracy, silently committing errors into the user's message would be worse
 * than one extra tap. A «use Google voice» escape is always visible when not
 * listening.
 *
 * <p>The engine lifecycle follows the RAM rule: it exists only inside a
 * session and {@link #stopDictation()} always releases it.
 */
public final class DictationView extends LinearLayout implements View.OnClickListener,
        UrduAsrEngine.Listener, OfflineVoiceManager.Listener {

    public interface OnDictationListener {
        /** Commit {@code text} into the host editor and return to the keyboard. */
        void onInsertText(String text);
        /** Leave the panel and use the legacy shortcut (Google) voice IME. */
        void onUseGoogleVoice();
        /** Back key: leave the panel without inserting anything. */
        void onDictationClosed();
    }

    private enum PanelState {
        NO_MODEL, DOWNLOADING, READY, LISTENING, PROCESSING, RESULT, ERROR
    }

    private OfflineVoiceManager mVoiceManager;
    private final UrduAsrEngine mEngine = new UrduAsrEngine();
    private OnDictationListener mListener;
    private PanelState mState = PanelState.NO_MODEL;
    private String mResultText;
    private int mTotalHeight;
    private int mNavigationBarInset;
    private int mContentBasePaddingBottom;

    private View mContent;
    private TextView mStatusText;
    private TextView mResultView;
    private ProgressBar mProgressBar;
    private ProgressBar mLevelBar;
    private ImageButton mMicButton;
    private TextView mPrimaryButton;
    private TextView mSecondaryButton;

    public DictationView(final Context context, final AttributeSet attrs) {
        this(context, attrs, R.attr.emojiPalettesViewStyle);
    }

    public DictationView(final Context context, final AttributeSet attrs, final int defStyle) {
        super(context, attrs, defStyle);
        mVoiceManager = OfflineVoiceManager.init(context);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        final Resources res = getContext().getResources();
        final int width = ResourceUtils.getKeyboardContentWidth(getContext())
                + getPaddingLeft() + getPaddingRight();
        final int height = (mTotalHeight > 0
                ? mTotalHeight
                : ResourceUtils.getDefaultKeyboardHeight(res)
                        + res.getDimensionPixelSize(R.dimen.config_suggestions_strip_height)
                        + mNavigationBarInset)
                + getPaddingTop() + getPaddingBottom();
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
    }

    /** Total height to occupy — the main keyboard frame's height including the suggestion bar. */
    public void setTotalHeight(final int height) {
        if (height > 0 && height != mTotalHeight) {
            mTotalHeight = height;
            requestLayout();
        }
    }

    public void setNavigationBarInset(final int inset) {
        if (inset == mNavigationBarInset) {
            return;
        }
        mNavigationBarInset = inset;
        mContent.setPadding(mContent.getPaddingLeft(), mContent.getPaddingTop(),
                mContent.getPaddingRight(), mContentBasePaddingBottom + inset);
        requestLayout();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        final int gutter = ResourceUtils.getKeyboardGutterWidth(getContext());
        setPadding(gutter, getPaddingTop(), gutter, getPaddingBottom());
        final ImageButton backKey = findViewById(R.id.dictation_back_key);
        backKey.setOnClickListener(v -> {
            if (mListener != null) {
                mListener.onDictationClosed();
            }
        });
        mContent = findViewById(R.id.dictation_content);
        mContentBasePaddingBottom = mContent.getPaddingBottom();
        mStatusText = findViewById(R.id.dictation_status);
        mResultView = findViewById(R.id.dictation_result);
        mProgressBar = findViewById(R.id.dictation_progress);
        mLevelBar = findViewById(R.id.dictation_level);
        mMicButton = findViewById(R.id.dictation_mic_button);
        mMicButton.setOnClickListener(this);
        mMicButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 36));
        mPrimaryButton = findViewById(R.id.dictation_primary_button);
        mPrimaryButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 18));
        mPrimaryButton.setOnClickListener(this);
        mSecondaryButton = findViewById(R.id.dictation_secondary_button);
        mSecondaryButton.setBackground(ClipboardHistoryView.createRoundedBackground(getContext(), 18));
        mSecondaryButton.setOnClickListener(this);
    }

    public void setOnDictationListener(final OnDictationListener listener) {
        mListener = listener;
    }

    public void startDictation() {
        mVoiceManager.setListener(this);
        if (mVoiceManager.getState() == OfflineVoiceManager.State.DOWNLOADING
                || mVoiceManager.getState() == OfflineVoiceManager.State.VERIFYING) {
            setState(PanelState.DOWNLOADING);
            onDownloadProgress(mVoiceManager.getDownloadedBytes(),
                    mVoiceManager.getTotalBytes());
        } else if (mVoiceManager.isModelReady()) {
            setState(PanelState.READY);
        } else {
            setState(PanelState.NO_MODEL);
        }
    }

    public void stopDictation() {
        mEngine.release();
        mVoiceManager.setListener(null);
    }

    // ---- Panel state rendering -------------------------------------------------

    private void setState(final PanelState state) {
        mState = state;
        mResultView.setVisibility(state == PanelState.RESULT ? VISIBLE : GONE);
        mProgressBar.setVisibility(state == PanelState.DOWNLOADING
                || state == PanelState.PROCESSING ? VISIBLE : GONE);
        mProgressBar.setIndeterminate(state == PanelState.PROCESSING);
        mLevelBar.setVisibility(state == PanelState.LISTENING ? VISIBLE : GONE);
        mMicButton.setVisibility(state == PanelState.READY || state == PanelState.LISTENING
                || state == PanelState.PROCESSING ? VISIBLE : GONE);
        mMicButton.setEnabled(state != PanelState.PROCESSING);
        mMicButton.setImageResource(state == PanelState.LISTENING
                ? R.drawable.ic_kb_mic_off : R.drawable.ic_kb_mic);
        mPrimaryButton.setVisibility(GONE);
        mSecondaryButton.setVisibility(GONE);
        switch (state) {
            case NO_MODEL:
                mStatusText.setText(getContext().getString(R.string.dictation_download_prompt,
                        formatMegabytes(mVoiceManager.getTotalBytes())));
                showButton(mPrimaryButton, R.string.dictation_download_button);
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
            case DOWNLOADING:
                mStatusText.setText(R.string.dictation_downloading);
                showButton(mPrimaryButton, R.string.dictation_cancel);
                break;
            case READY:
                mStatusText.setText(R.string.dictation_ready_hint);
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
            case LISTENING:
                mStatusText.setText(R.string.dictation_listening);
                showButton(mPrimaryButton, R.string.dictation_stop);
                showButton(mSecondaryButton, R.string.dictation_cancel);
                break;
            case PROCESSING:
                mStatusText.setText(R.string.dictation_processing);
                break;
            case RESULT:
                mStatusText.setText(R.string.dictation_result_title);
                mResultView.setText(mResultText);
                showButton(mPrimaryButton, R.string.dictation_insert);
                showButton(mSecondaryButton, R.string.dictation_retry);
                break;
            case ERROR:
                showButton(mSecondaryButton, R.string.dictation_use_google);
                break;
        }
    }

    private void showButton(final TextView button, final int textRes) {
        button.setText(textRes);
        button.setVisibility(VISIBLE);
    }

    private static String formatMegabytes(final long bytes) {
        return String.format("%.0f MB", bytes / 1_000_000.0);
    }

    // ---- Clicks ------------------------------------------------------------------

    @Override
    public void onClick(final View v) {
        if (v == mMicButton) {
            if (mState == PanelState.READY) {
                mEngine.startSession(mVoiceManager.getModelDir(), this);
            } else if (mState == PanelState.LISTENING) {
                mEngine.stopCaptureAndDecode(this);
            }
            return;
        }
        if (v == mPrimaryButton) {
            switch (mState) {
                case NO_MODEL:
                case ERROR:
                    mVoiceManager.startDownload();
                    break;
                case DOWNLOADING:
                    mVoiceManager.cancelDownload();
                    break;
                case LISTENING:
                    mEngine.stopCaptureAndDecode(this);
                    break;
                case RESULT:
                    if (mListener != null && mResultText != null) {
                        mListener.onInsertText(mResultText);
                    }
                    break;
                default:
                    break;
            }
            return;
        }
        if (v == mSecondaryButton) {
            switch (mState) {
                case NO_MODEL:
                case READY:
                case ERROR:
                    if (mListener != null) {
                        mListener.onUseGoogleVoice();
                    }
                    break;
                case LISTENING:
                    mEngine.cancelCapture();
                    setState(PanelState.READY);
                    break;
                case RESULT:
                    setState(PanelState.READY);
                    break;
                default:
                    break;
            }
        }
    }

    // ---- UrduAsrEngine.Listener ----------------------------------------------------

    @Override
    public void onListening() {
        setState(PanelState.LISTENING);
    }

    @Override
    public void onLevel(final float level) {
        if (mState == PanelState.LISTENING) {
            mLevelBar.setProgress((int) (level * 100));
        }
    }

    @Override
    public void onDecoding() {
        setState(PanelState.PROCESSING);
    }

    @Override
    public void onResult(final String text) {
        mResultText = text;
        setState(PanelState.RESULT);
    }

    @Override
    public void onError(final UrduAsrEngine.ErrorKind kind) {
        // setState(ERROR) leaves the status line alone, so the specific error
        // text is applied after it.
        setState(PanelState.ERROR);
        switch (kind) {
            case ENGINE_UNAVAILABLE:
                mStatusText.setText(R.string.dictation_engine_missing);
                break;
            case LOAD_FAILED:
                mStatusText.setText(R.string.dictation_load_failed);
                break;
            case NO_AUDIO:
                mStatusText.setText(R.string.dictation_no_audio);
                break;
            case DECODE_FAILED:
            default:
                mStatusText.setText(R.string.dictation_decode_failed);
                break;
        }
    }

    // ---- OfflineVoiceManager.Listener ----------------------------------------------

    @Override
    public void onDownloadProgress(final long bytesDone, final long bytesTotal) {
        if (mState == PanelState.DOWNLOADING && bytesTotal > 0) {
            mProgressBar.setIndeterminate(false);
            mProgressBar.setProgress((int) (bytesDone * 100 / bytesTotal));
        }
    }

    @Override
    public void onStateChanged(final OfflineVoiceManager.State state) {
        switch (state) {
            case DOWNLOADING:
            case VERIFYING:
                setState(PanelState.DOWNLOADING);
                break;
            case READY:
                setState(PanelState.READY);
                break;
            case ERROR:
                setState(PanelState.ERROR);
                mStatusText.setText(R.string.dictation_download_failed);
                showButton(mPrimaryButton, R.string.dictation_download_button);
                break;
            case ABSENT:
            default:
                setState(PanelState.NO_MODEL);
                break;
        }
    }
}
